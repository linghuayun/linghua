<?php
if(!defined('IN_CRONLITE'))exit();
$bili = round($cutrow['cut_price'] / $cutrow['price'] * 100, 2);
if ($bili < 0) {
    $bar = 'danger';
} elseif ($bili < 30) {
    $bar = 'warning';
} elseif ($bili < 60) {
    $bar = 'info';
} elseif ($bili <= 100) {
    $bar = 'success';
}
$timestr=$cutrow['endtime'];//倒计时时间
$time = strtotime($timestr);//时间戳
$nowtime = time();//当前时间戳
 if($time>=$nowtime){$overtime = $time-$nowtime;}else{$overtime=0;}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
    <title>我正在免费拿商品【<?php echo $shoprow['name'];?>】 - 快来帮我砍一刀</title>
    <link rel="stylesheet" href="<?php echo $cdnserver?>assets/simple/css/oneui.css">
	<link href="<?php echo $cdnpublic?>font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
	<link rel="stylesheet" href="<?php echo $cdnserver?>assets/css/common.css?ver=<?php echo VERSION ?>">
    <script src="<?php echo $cdnpublic?>modernizr/2.8.3/modernizr.min.js"></script>
    <!--[if lt IE 9]>
      <script src="<?php echo $cdnpublic?>html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="<?php echo $cdnpublic?>respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<?php echo $background_css?>
</head>
<body>
<br/>
<div class="col-xs-12 col-sm-10 col-md-8 col-lg-5 center-block" style="float: none;">
<div class="block" style="box-shadow:0px 5px 10px 0 rgba(0, 0, 0, 0.25);" id="backHome">
<a class="btn btn-block" href="./?mod=cutshop"><i class="fa fa-shopping-cart"></i>  我要免费拿</a>
</div>

<div class="block block-bordered" id="tocutshop" style="box-shadow:0px 5px 10px 0 rgba(0, 0, 0, 0.25);">
  <div class="block-header bg-gray-lighter">
   <h3 class="block-title"><i class="fa fa-shopping-cart"></i>&nbsp;我正在免费拿商品【<?php echo $shoprow['name'];?>】</h3>
  </div>
  <div class="block-content">
    <div class="tab-pane fade active in">
        <div class="alert alert-info">
          温馨提示：商品砍价金额随机，不存在最后越砍越少的情况，请大家踊跃参与哦~
        </div>
        <div class="alert alert-danger text-center">
          <h4>
            <span id="hideD"><strong id="RemainD"></strong></span>
            <span id="hideH"><strong id="RemainH"></strong></span><font color="#3B3B3B"> :</font>
            <span id="hideM"><strong id="RemainM"></strong></span><font color="#3B3B3B"> :</font>
            <span id="hideS"><strong id="RemainS"></strong></span><font color="#3B3B3B">  后小队过期</font>
          </h4>
        </div>
        <div class="panel panel-default">
        <div class="cut-shop" styple="box-shadow: 0px 0px 6px #eee; border-radius: 0.5em;">
          <div class="cut-shopimg">
            <img src="<?php echo $shoprow['shopimg'];?>" alt="..." class="cut-shopimg-img" onerror="this.src='assets/img/cutimg.png'"/>
          </div>
          <div class="cut-content">
            <div class="cut-title" style="height: 70px;">
              <?php echo $shoprow['name'];?>
            </div>
            <div class="cut-info">
              <b style="color: red">
                <span class="fa fa-rmb"></span>
                  &nbsp;<?php echo $cutrow['price'];?>&nbsp;元
              </b>
            </div>
          </div>
        </div>
        </div>
            <div id="cut-kjbox">
              <div class="cut-jindu">
                <div class="cut-jindu-info text-center">
                <?php
                if (floatval($cutrow['cut_price']) >= floatval($cutrow['price'])) {
                  echo '已砍 <span style="color: red">' . floatval($cutrow['cut_price']) . '</span> 元，砍价已完成！';
                } else {
                  echo '已砍 <span style="color: red">' . floatval($cutrow['cut_price']) . '</span> 元，还剩 <span style="color: red">' . floatval($cutrow['price'] - $cutrow['cut_price']) . '</span> 元';
                }
                ?>
                </div>
              </div>
              <div class="progress progress-striped active">
                <div class="progress-bar progress-bar-<?php echo $bar?>" role="progressbar" aria-valuenow="<?php echo $bili?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $bili?>%;"><?php echo $bili?>%</div>
              </div>
              <input type="hidden" name="captcha_open" value="<?php echo $conf['captcha_open']?>"/>
              <input type="hidden" name="appid" value="<?php echo $conf['captcha_id']?>"/>
              <div class="form-group">
                <?php
                if ($cutrow['status'] >= 1) {
                  echo '<input type="submit" name="submit" value="砍价已完成" class="btn btn-success btn-block">';
                } else if ($cutrow['endtime'] <= $date) {
                  echo '<input type="submit" name="submit" value="砍价已过期" class="btn btn-danger btn-block">';
                } else if ($islogin2 == 1 && ($cutrow['zid'] == $userrow['zid'])) {
                  echo '<input type="submit" name="submit" id="submit_cutshow" value="邀请好友帮忙砍" class="btn btn-info btn-block" onclick="cutshow('.$cutrow['id'].','.$cutshoprow['tid'].')">';
                } else if ($DB->getRow("SELECT * FROM `pre_cutlog` WHERE `iid`=:iid AND `ip`=:ip LIMIT 1", [':iid'=>$cutrow['id'], ':ip'=>$clientip])) {
                  echo '<input type="submit" name="submit" value="您已帮他砍过了" class="btn btn-info btn-block">';
                } else {
                  echo '<input type="submit" name="submit" id="submit_helpcut" value="帮他砍一刀" class="btn btn-primary btn-block" style="background-color: #7266ba; border-color: #7266ba;">';
                }
                ?>
              </div>
            </div>
        </div>
      </div>
    </div>
<div class="block block-bordered" id="tocutshop" style="box-shadow:0px 5px 10px 0 rgba(0, 0, 0, 0.25);">
  <div class="block-header bg-gray-lighter">
   <h3 class="block-title text-center"><i class="fa fa-group"></i>&nbsp;砍价帮</h3>
  </div>
  <div class="block-content">
    <div class="tab-pane fade active in">
    <marquee class="zmd" behavior="scroll" direction="UP" onmouseover="this.stop()" onmouseout="this.start()" scrollamount="5" style="height:10em">
    <?php
    $logrs = $DB->query("SELECT * FROM `pre_cutlog` WHERE 1 ORDER BY id DESC LIMIT 100");
    while ($logres = $logrs->fetch()) {
        if ($logres['money'] == 0) {
            $logres['money'] = round((rand(1, 1000)) / 100, 2);
        }
        $ip = substr($logres['ip'], 4, strripos($logres['ip'], ".") - 1);
        $ip = '***' . $ip . '***';
        echo '<div class="cut-tab-list">来自' . $ip . '的好友成功帮用户砍掉' . $logres['money'] . '元</div>';
    }
    ?>
    </marquee>
    </div>
  </div>
</div>
</div>
<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo $cdnpublic ?>jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="<?php echo $cdnpublic ?>layer/2.3/layer.js"></script>
<script src="<?php echo $cdnpublic ?>clipboard.js/1.7.1/clipboard.min.js"></script>
<script language="JavaScript">
    var runtimes = 0;
    function GetRTime(){
        var nMS = <?php echo $overtime; ?>*1000-runtimes*1000;
        if (nMS>=0){
            var nD=Math.floor(nMS/(1000*60*60*24))%24;
            var nH=Math.floor(nMS/(1000*60*60))%24;
            var nM=Math.floor(nMS/(1000*60)) % 60;
            var nS=Math.floor(nMS/1000) % 60;
            document.getElementById("RemainD").innerHTML=nD;
            document.getElementById("RemainH").innerHTML=nH;
            document.getElementById("RemainM").innerHTML=nM;
            document.getElementById("RemainS").innerHTML=nS;
            runtimes++;
            if(0==0){
                //天数0 隐藏天数
                document.getElementById("hideD").style.display="none";
                if(1==0){
                    //数0 隐藏天数
                    document.getElementById("hideH").style.display="none";
                    if(1==0){
                        document.getElementById("hideM").style.display="none";
                        
                        if(nS==0){
                        
                        }
                    }
                }
            }
            setTimeout("GetRTime()",1000);
        }
    }
    window.onload = function() {
        GetRTime();
    }
</script>
<script src="assets/js/helpcut.js?ver=<?php echo VERSION ?>"></script>
</body>
</html>