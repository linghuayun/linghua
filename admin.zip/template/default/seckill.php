<?php
if(!defined('IN_CRONLITE'))exit();
if(!$conf['seckill_open'])exit("<script language='javascript'>alert('当前站点未开启秒杀专场功能');window.location.href='./';</script>");

$islogin2 = $islogin2?1:0;
$rs=$DB->query("SELECT A.*,B.name,B.shopimg FROM pre_seckillshop A LEFT JOIN pre_tools B ON A.tid=B.tid WHERE A.active=1 ORDER BY A.sort ASC");
$seckill = array();
while($res = $rs->fetch())
{
	$seckill[] = $res;
}
$count = count($seckill);
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
    <title>秒杀专场 - <?php echo $conf['sitename']?></title>
    <link rel="stylesheet" href="<?php echo $cdnserver?>assets/simple/css/oneui.css">
	<link href="<?php echo $cdnpublic?>font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
	<link rel="stylesheet" href="<?php echo $cdnserver?>assets/css/common.css?ver=<?php echo VERSION ?>">
    <script src="<?php echo $cdnpublic?>modernizr/2.8.3/modernizr.min.js"></script>
    <!--[if lt IE 9]>
      <script src="<?php echo $cdnpublic?>html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="<?php echo $cdnpublic?>respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<?php echo $background_css?>
</head>
<body>
<br/>
<div class="col-xs-12 col-sm-10 col-md-8 col-lg-5 center-block" style="float: none;">
<div class="block" style="box-shadow:0px 5px 10px 0 rgba(0, 0, 0, 0.25);" id="backHome">
<a class="btn btn-block" href="./"><i class="fa fa-mail-reply-all"></i>  返回网站首页</a>
</div>

<div class="block block-bordered" style="box-shadow:0px 5px 10px 0 rgba(0, 0, 0, 0.25);">
  <div class="block-header bg-gray-lighter">
   <h3 class="block-title"><i class="fa fa-shopping-cart"></i>&nbsp;秒杀专场共 <?php echo $count?> 件商品</h3>
  </div>
  <div class="block-content" id="toseckillshop" style="display: none;">
    <div class="tab-pane fade active in">
      <div class="form-group">
        <div class="hide" id="tidframe"></div>
		<div class="input-group">
			<div class="input-group-addon">商品名称</div>
			<input type="text" name="name" id="name" class="form-control" style="center;color:#4169E1;font-weight:bold" disabled/>
		</div><br/>
		<div class="input-group" style="center;color:#4169E1;font-weight:bold">
			<div class="input-group-addon">商品价格</div>
			<input type="text" name="need" id="need" class="form-control" style="center;color:#4169E1;font-weight:bold" disabled/>
		</div></br>
        <div id="inputsname"></div>
        <div id="alert_frame" class="alert alert-success" style="background: linear-gradient(to right, rgb(113, 215, 162), rgb(94, 209, 215)); font-weight: bold; color: white;display: none"></div>
      </div>
      <div class="form-group">
        <input type="submit" name="submit" id="submit_buy" value="立即下单" class="btn btn-info btn-block">
      </div>
      <div class="form-group">
        <input type="submit" name="submit" id="submit_reply" value="返回列表" class="btn btn-default btn-block">
      </div>
    </div>
  </div>
    <div class="block-content row" id="seckillshop">
		<div class="alert alert-info">
			注：请先登录平台，选择下方的商品，在规定的时间内进行低价秒杀，过时或数量秒杀完了无法继续秒杀
		</div>
		<?php
		foreach($seckill as $row){
		$grouprow = $DB->getRow("SELECT * FROM `pre_group` WHERE `zid`='{$userrow['zid']}' AND tid='{$row['tid']}' LIMIT 1");
		?>
		<div class="col-xs-6 col-sm-3 col-md-3">
			<div class="thumbnail">
				<img src="<?php echo $row['shopimg'];?>" alt="..." height="120" onerror="this.src='assets/img/seckillimg.png'">
				<div class="caption">
					<h6>剩余<font color=red><?php echo $row['num']-$row['count']?></font>份</h6>
					<h4><?php echo $row['name'];?></h4>
					<h6>开始时间:<font color=red><?php echo $row['starttime'];?></font></h6>
					<h6>结束时间:<font color=red><?php echo $row['endtime'];?></font></h6>
				</div>
				<button class="btn btn-block btn-danger" onclick="seckill_create(<?php echo $row['id'];?>);"><?php echo $row['price'];?>元秒杀</button>
			</div>
		</div>
		<?php }?>
	</div>
  </div>

<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo $cdnpublic ?>jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="<?php echo $cdnpublic ?>layer/2.3/layer.js"></script>
<script type="text/javascript">
var hashsalt=<?php echo $addsalt_js?>;
var islogin=<?php echo $islogin2?>;
</script>
<script src="assets/js/seckill.js?ver=<?php echo VERSION ?>"></script>
</body>
</html>