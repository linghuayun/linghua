<?php
/**
 * 供货商登录修复 
**/
include("../includes/common.php");

if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

adminpermission('site', 2);

$sid=intval($_GET['sid']);

$suprow=$DB->getRow("select * from pre_supplier where sid='$sid' limit 1");
if(!$suprow)sysmsg('当前用户不存在！');

$session=md5($suprow['user'].$suprow['pwd'].$password_hash);
$token=authcode("{$sid}\t{$session}", 'ENCODE', SYS_KEY);
setcookie("sup_token", $token, time() + 604800, '/');

exit("<script language='javascript'>window.location.href='../sup/';</script>");
