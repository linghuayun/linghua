<?php


include "../includes/common.php";
$title = "检查版本更新";
if ($islogin == 1) {
} else {
	exit("<script language='javascript'>window.location.href='./login.php';</script>");
}
include "./head.php";
?>
	
					</div>
					<ul class="list-group text-dark">
						<li class="list-group-item" id="notice"><p><font color="#DC143C">自助下单系统已关闭在线更新</font><br><font color="#DC143C">更新方法</font><br><font color="#DC143C">加入QQ群</font></p></li>
