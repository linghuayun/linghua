<?php
if($newuserfoot){
	include($newuserfoot);
	return;
}
?>
</div>


