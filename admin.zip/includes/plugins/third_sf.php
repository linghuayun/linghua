<?php
namespace plugins;

class third_sf{

	private $config = [];

	static public $info = [
		'name'        => 'third_sf',
		'type'        => 'third',
		'title'       => 'SF自助下单系统对接',
		'author'      => '绫华',
		'version'     => '1.0',
		'link'        => '',
		'sort'        => 32,
		'showedit'    => false,
		'showip'      => false,
		'pricejk'     => 1,
		'input' => [
			'url' => '网站域名',
			'username' => '登录账号',
			'password' => '登录密码',
			'paypwd' => false,
			'paytype' => false,
		],
	];

	public function __construct($config)
	{
		$this->config = $config;
	}

	public function do_goods($goods_id, $goods_type, $goods_param, $num = 1, $input = array(), $money, $tradeno, $inputsname)
	{
		$result['code'] = -1;
		$url = '/api.php?act=pay';
		$param = array();
		$param['tid'] = $goods_id;
		$param['user'] = $this->config['username'];
		$param['pass'] = $this->config['password'];
		$param['num'] = $num;
		if(is_array($input) && $input) {
			$i = 1; 
			foreach ($input as $val) {
				if($val){
					$param[ 'input' . $i ] = $val;
					$i++;
				}
			}
		}
		$post = http_build_query($param);
		$data = $this->get_curl($url,$post);
		$json = json_decode($data,true);
		if (isset($json['orderid'])) {
			$result = array(
				'code' => 0,
				'id' => $json['orderid']
			);
			if($json['faka']==true){
				$result['faka']=true;
				$result['kmdata']=$json['kmdata'];
			}
		} elseif(isset($json['message'])){
			$result['message'] = $json['message'];
		} else{
			$result['message'] = $data;
		}
		return $result;
	}

	public function goods_info($goods_id){
		$url = '/sf_api.php?act=goodsdetails';
		$post = 'tid='.$goods_id.'&user='.urlencode($this->config['username']).'&pass='.urlencode($this->config['password']);
		$data = $this->get_curl($url, $post);
		if (!$ret = json_decode($data, true)) {
			return '打开对接网站失败';
		} elseif ($ret['code'] != 0) {
			return $ret['message'];
		} else {
			if($ret['data']['shopimg']&&substr($ret['data']['shopimg'],0,4)!='http'&&substr($ret['data']['shopimg'],0,2)!='//')$ret['data']['shopimg'] = ($this->config['protocol']==1?'https://':'http://') . $this->config['url'] .'/'.$ret['data']['shopimg'];
			return $ret['data'];
		}
	}
	
	public function query_order($orderid, $goodsid, $value = []){
		$order_state = array(0=>'待处理',1=>'已完成',2=>'正在处理',3=>'异常',4=>'已退单');
		$url = '/api.php?act=search&id='.$orderid;
		$post = 'user='.urlencode($this->config['username']).'&pass='.urlencode($this->config['password']);
		$data = $this->get_curl($url, $post);
		if (!$arr = json_decode($data , true)) {
			return false;
		} elseif (isset($arr['code']) && $arr['code'] == 0) {
			if (isset($arr['data']) && is_array($arr['data'])) {
				return $arr['data'];
			} elseif(isset($arr['status'])) {
				return ['订单状态'=>$order_state[$arr['status']]];
			}
		} elseif (isset($arr['message'])) {
			return $arr['message'];
		}
	}

	public function class_list(){
		$url = '/api.php?act=classlist';
		$ret = $this->get_curl($url);
		if (!$ret = json_decode($ret, true)) {
			return '打开对接网站失败';
		}  elseif ($ret['code'] == -5) {
			return '对方网站未更新最新版本';
		} elseif ($ret['code'] != 0) {
			return $ret['message'];
		} else {
			return $ret['data'];
		}
	}
	
	public function goods_list_by_cid($cid){
		$url = '/api.php?act=goodslistbycid';
		$post = 'cid='.$cid.'&user='.urlencode($this->config['username']).'&pass='.urlencode($this->config['password']);
		$ret = $this->get_curl($url, $post);
		if (!$ret = json_decode($ret, true)) {
			return '打开对接网站失败';
		} elseif ($ret['code'] == -5) {
			return '对方网站未更新最新版本';
		} elseif ($ret['code'] != 0) {
			return $ret['message'];
		} else {
			$list = [];
			foreach ($ret['data'] as $v) {
				if($v['shopimg']&&substr($v['shopimg'],0,4)!='http'&&substr($v['shopimg'],0,2)!='//')$v['shopimg'] = ($this->config['protocol']==1?'https://':'http://') . $this->config['url'] .'/'.$v['shopimg'];
				if($v['classimg']&&substr($v['classimg'],0,4)!='http'&&substr($v['classimg'],0,2)!='//')$v['classimg'] = ($this->config['protocol']==1?'https://':'http://') . $this->config['url'] .'/'.$v['classimg'];
				$list[] = $v;
			}
			return $list;
		}
	}
	public function goods_list(){
		$url = '/sf_api.php?act=goodslist';
		$post = 'user='.urlencode($this->config['username']).'&pass='.urlencode($this->config['password']);
		$ret = $this->get_curl($url, $post);
		if (!$ret = json_decode($ret, true)) {
			return '打开对接网站失败';
		} elseif ($ret['code'] != 0) {
			return $ret['message'];
		} else {
			$list = array();
			foreach ($ret['data'] as $v) {
				if($v['shopimg']&&substr($v['shopimg'],0,4)!='http'&&substr($v['shopimg'],0,2)!='//')$v['shopimg'] = 'http://'.$this->config['url'].'/'.$v['shopimg'];
				$list[] = array(
					'id' => $v['tid'],
					'close' => $v['close'],
					'price' => $v['price'],
					'stock' => $v['stock'],
					'is_synchronization' => $v['is_synchronization']
				);
			}
			return $list;
		}
	}
    public function goods_list2(){
		$url = '/sf_api.php?act=goodslist';
		$post = 'user='.urlencode($this->config['username']).'&pass='.urlencode($this->config['password']);
		$ret = $this->get_curl($url, $post);
		if (!$ret = json_decode($ret, true)) {
			return '打开对接网站失败';
		} elseif ($ret['code'] != 0) {
			return $ret['message'];
		} else {
			$list = array();
			foreach ($ret['data'] as $v) {
				$list[$v['tid']] = array(
					'close' => $v['close'],
					'price' => $v['price'],
					'stock' => $v['stock'],
					'is_synchronization' => $v['is_synchronization']
				);
			}
			return $list;
		}
	}
    public function all_goods_list($page = 1, $num = 30, $cid = -1, $kw = '', $range = 'all', $status = 'all', $shequ = ''){
        global $DB;
		$url = '/sf_api.php?act=allgoodslist&num='.$num.'&page='.$page;
		$post = [
		    'kw' => $kw,
		    'range' => $range,
		    'status' => $status,
		    'cid' => $cid,
		    'user' => urlencode($this->config['username']),
		    'pass' => urlencode($this->config['password'])
	    ];
		if($status != 'all'){
		    if(empty($shequ))return '参数错误！';
		    $rs = $DB->query("SELECT goods_id FROM pre_tools WHERE shequ = '$shequ'");
		    $data = [];
		    while($res = $rs->fetch()){
			    $data[] = $res['goods_id'];
			}
		    $post['status_result'] = json_encode(!empty($data)?$data:[0]);
		}
		$ret = $this->get_curl($url, $post);
		if (!$ret = json_decode($ret, true)) {
			return '打开对接网站失败';
		} elseif ($ret['code'] == -5) {
			return '对方网站未更新最新版本';
		} elseif ($ret['code'] != 0) {
			return $ret['message'];
		} else {
			$list = [];
			foreach ($ret['data'] as $v) {
				if($v['shopimg']&&substr($v['shopimg'],0,4)!='http'&&substr($v['shopimg'],0,2)!='//')$v['shopimg'] = ($this->config['protocol']==1?'https://':'http://') . $this->config['url'] .'/'.$v['shopimg'];
				$list[] = $v;
			}
			return ['list' => $list, 'page' => $ret['page'], 'count' => $ret['count']];
		}
	}
    
    public function synchronization($shequid,&$success,&$add_success,&$update_success){
        global $DB,$conf;
		$goods_list = $this->goods_list2();
		if(is_array($goods_list)){
			
			$class_arr = explode(',',$conf['synchronization_cid']);
			$all = false;
			if(in_array('all',$class_arr)){
			    $all = true;
			}
			$local_goods_list = [];
			$rs=$DB->query("SELECT cid,goods_id,price,value,prid,tid,close,stock FROM pre_tools WHERE is_curl=2 AND shequ='{$shequid}'");
			while($res = $rs->fetch())
			{   
			    $local_goods_list[$res['goods_id']] = $res['tid'];
			    if(!$all){
			        if(!in_array($res['cid'],$class_arr))continue;
			    }
			    if($goods_list[$res['goods_id']]['is_synchronization'] == 1)continue;
				if($res['price']==='0.00')continue;
				if(empty($goods_list[$res['goods_id']])){
				    $DB->exec("update `pre_tools` set `close` ='0' where `tid`='{$res['tid']}'");
					$success++;
					continue;
				}
				if(!empty($goods_list[$res['goods_id']]['price']) && $goods_list[$res['goods_id']]['price'] > 0 && $res['prid'] > 0){
					$price = ceil($goods_list[$res['goods_id']]['price'] * $res['value'] * 100)/100;
					if($conf['synchronization_edit']==1 && $price > $res['price']){
						$DB->exec("update `pre_tools` set `price` ='{$price}' where `tid`='{$res['tid']}'");
						$success++;
					}elseif($conf['synchronization_edit']==0 && $price != $res['price']){
						$DB->exec("update `pre_tools` set `price` ='{$price}' where `tid`='{$res['tid']}'");
						$success++;
					}
				}
				if(isset($goods_list[$res['goods_id']]['close'])){
					if($goods_list[$res['goods_id']]['close'] == 1 && $res['close']==0){
						$DB->exec("update `pre_tools` set `close`=1 where `tid`='{$res['tid']}'");
					}elseif($goods_list[$res['goods_id']]['close'] == 0 && $res['close']==1){
						$DB->exec("update `pre_tools` set `close`=0 where `tid`='{$res['tid']}'");
					}
				}else{
					$DB->exec("update `pre_tools` set `close`=1 where `tid`='{$res['tid']}'");
				}
				if(isset($goods_list[$res['goods_id']]['stock']) && $goods_list[$res['goods_id']]['stock'] !== null && $res['stock'] != $goods_list[$res['goods_id']]['stock']){
					$DB->exec("update `pre_tools` set `stock`=:stock where `tid`='{$res['tid']}'", [':stock'=>$goods_list[$res['goods_id']]['stock']]);
				}
				unset($goods_list[$res['goods_id']]);
			}
			if(!empty($goods_list)){
			    foreach ($goods_list as $k => $v){
			        $is_update = false;
			        if(empty($local_goods_list)){
			            $tool = $DB->getRow("SELECT tid FROM pre_tools WHERE shequ=:shequ AND goods_id=:goods_id LIMIT 1", [':shequ'=>$shequid, ':goods_id'=>$k]);
			            if($tool){
			                if($v['is_synchronization'] == 0)continue;
			                $is_update = true;
			            }
			        }else{
			            if(array_key_exists($k,$local_goods_list)){
			                if($v['is_synchronization'] == 0)continue;
			                $is_update = true;
			                $tool = ['tid' => $local_goods_list[$k]];
			            }
			        }
			        $goods_info = $this->goods_info($k);
			        if(is_array($goods_info)){
			            if(empty($goods_info['tid']))continue;
			            if($conf['synchronization_class'] == 'new' || $tool){
		                    if(!empty($goods_info['classname'])){
            		            $classrow = $DB->getRow("SELECT name,cid FROM pre_class WHERE name=:name LIMIT 1", [':name'=>$goods_info['classname']]);
                		        if(!$classrow){
                        		    $sort = $DB->getColumn("select sort from pre_class order by sort desc limit 1");
                        		    $sql = "insert into `pre_class` (`name`,`shopimg`,`sort`,`active`) values (:name,:shopimg,:sort,1)";
                            		if(!$DB->exec($sql, [':name'=>$goods_info['classname'], ':shopimg'=>$goods_info['classimg'], ':sort'=>$sort+1])){
                                			$mcid = 0;
                        		    }
                    		        $mcid = $DB->lastInsertId();
                		        }else{
                    		        $mcid = $classrow['cid'];
                    		    }
                	        }else{
                	            $mcid = 0;
                	        }
			            }else{
			                $mcid = $conf['synchronization_class'];
			            }
			            if($is_update){
                			$sql = "UPDATE `pre_tools` SET `cid`=:cid,`name`=:name,`price`=:price,`cost`=:cost,`cost2`=:cost2,`prices`=:prices,`input`=:input,`inputs`=:inputs,`desc`=:desc,`alert`=:alert,`shopimg`=:shopimg,`value`=:value,`is_curl`=:is_curl,`curl`=:curl,`shequ`=:shequ,`goods_id`=:goods_id,`goods_type`=:goods_type,`goods_param`=:goods_param,`repeat`=:repeat,`multi`=:multi,`min`=:min,`max`=:max,`validate`=:validate,`valiserv`=:valiserv,`close`=:close,`stock`=:stock WHERE `tid`=:tid";
                			$data = [':cid'=>$mcid, ':name'=>$goods_info['name'], ':price'=>$goods_info['price'], ':cost'=>0, ':cost2'=>0, ':prices'=>'', ':input'=>$goods_info['input'], ':inputs'=>$goods_info['inputs'], ':desc'=>$goods_info['desc'], ':alert'=>$goods_info['alert'], ':shopimg'=>$goods_info['shopimg'], ':value'=>1, ':is_curl'=>2, ':curl'=>null, ':shequ'=>$shequ, ':goods_id'=>$goods_info['tid'], ':goods_type'=>$goods_info['isfaka']?'1':'0', ':goods_param'=>null, ':repeat'=>$goods_info['repeat'], ':multi'=>$goods_info['multi'], ':min'=>$goods_info['min'], ':max'=>$goods_info['max'], ':validate'=>$goods_info['validate'], ':valiserv'=>$goods_info['valiserv'], ':close'=>$goods_info['close'], ':stock'=>$goods_info['stock'], ':tid'=>$tool['tid']];
                			$DB->exec($sql, $data);
                			$update_success++;
			            }else{
                			$sql = "INSERT INTO `pre_tools` (`cid`,`name`,`price`,`cost`,`cost2`,`prid`,`prices`,`input`,`inputs`,`desc`,`alert`,`shopimg`,`value`,`is_curl`,`curl`,`shequ`,`goods_id`,`goods_type`,`goods_param`,`repeat`,`multi`,`min`,`max`,`validate`,`valiserv`,`close`,`active`,`addtime`) VALUES (:cid,:name,:price,:cost,:cost2,:prid,:prices,:input,:inputs,:desc,:alert,:shopimg,:value,:is_curl,:curl,:shequ,:goods_id,:goods_type,:goods_param,:repeat,:multi,:min,:max,:validate,:valiserv,:close,:active,NOW())";
                			$data = [':cid'=>$mcid, ':name'=>$goods_info['name'], ':price'=>$goods_info['price'], ':cost'=>0, ':cost2'=>0, ':prid'=>$conf['synchronization_prid'], ':prices'=>'', ':input'=>$goods_info['input'], ':inputs'=>$goods_info['inputs'], ':desc'=>$goods_info['desc'], ':alert'=>$goods_info['alert'], ':shopimg'=>$goods_info['shopimg'], ':value'=>1, ':is_curl'=>2, ':curl'=>null, ':shequ'=>$shequid, ':goods_id'=>$goods_info['tid'], ':goods_type'=>$goods_info['isfaka']?'1':'0', ':goods_param'=>null, ':repeat'=>$goods_info['repeat'], ':multi'=>$goods_info['multi'], ':min'=>$goods_info['min'], ':max'=>$goods_info['max'], ':validate'=>$goods_info['validate'], ':valiserv'=>$goods_info['valiserv'], ':close'=>$goods_info['close'], ':active'=>1];
                			$DB->exec($sql, $data);
                			$add_success++;
			            }
			        }
			    }
			}
			return true;
		}else{
			return $list;
		}
    }

	public function pricejk($shequid,&$success){
		global $DB,$conf;
		$list = $this->goods_list();
		if(is_array($list)){
			$price_arr = array();
			$goods_status_arr = array();
			$stock_arr = array();
			foreach($list as $row){
				$price_arr[$row['id']] = $row['price'];
				$goods_status_arr[$row['id']] = $row['close']; //商品状态 1为禁止下单
				$stock_arr[$row['id']] = $row['stock']; //库存
			}
			$rs2=$DB->query("SELECT * FROM pre_tools WHERE is_curl=2 AND shequ='{$shequid}' AND active=1 AND cid IN ({$conf['pricejk_cid']})");
			while($res2 = $rs2->fetch())
			{
				if($res2['price']==='0.00')continue;
				if(isset($price_arr[$res2['goods_id']]) && $price_arr[$res2['goods_id']]>0 && $res2['prid']>0){
					$price = ceil($price_arr[$res2['goods_id']] * $res2['value'] * 100)/100;
					if($conf['pricejk_edit']==1 && $price>$res2['price']){
						$DB->exec("update `pre_tools` set `price` ='{$price}' where `tid`='{$res2['tid']}'");
						$success++;
					}elseif($conf['pricejk_edit']==0 && $price!=$res2['price']){
						$DB->exec("update `pre_tools` set `price` ='{$price}' where `tid`='{$res2['tid']}'");
						$success++;
					}
				}
				if(isset($goods_status_arr[$res2['goods_id']])){
					if($goods_status_arr[$res2['goods_id']]==1 && $res2['close']==0){
						$DB->exec("update `pre_tools` set `close`=1 where `tid`='{$res2['tid']}'");
					}elseif($goods_status_arr[$res2['goods_id']]==0 && $res2['close']==1){
						$DB->exec("update `pre_tools` set `close`=0 where `tid`='{$res2['tid']}'");
					}
				}else{
					$DB->exec("update `pre_tools` set `close`=1 where `tid`='{$res2['tid']}'");
				}
				if(isset($stock_arr[$res2['goods_id']]) && $stock_arr[$res2['goods_id']]!==null && $res2['stock']!=$stock_arr[$res2['goods_id']]){
					$DB->exec("update `pre_tools` set `stock`=:stock where `tid`='{$res2['tid']}'", [':stock'=>$stock_arr[$res2['goods_id']]]);
				}
			}
			return true;
		}else{
			return $list;
		}
	}

	private function get_curl($path,$post=0){
		$url = ($this->config['protocol']==1?'https://':'http://') . $this->config['url'] . $path;
		return get_curl($url,$post);
	}
}