-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2023-08-10 14:51:57
-- 服务器版本： 8.0.32
-- PHP 版本： 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `linghua`
--

-- --------------------------------------------------------

--
-- 表的结构 `shua_account`
--

DROP TABLE IF EXISTS `shua_account`;
CREATE TABLE `shua_account` (
  `id` int UNSIGNED NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `permission` text,
  `addtime` datetime DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_apps`
--

DROP TABLE IF EXISTS `shua_apps`;
CREATE TABLE `shua_apps` (
  `id` int NOT NULL,
  `zid` int UNSIGNED NOT NULL DEFAULT '1',
  `taskid` int UNSIGNED NOT NULL DEFAULT '0',
  `domain` varchar(128) NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `icon` varchar(256) DEFAULT NULL,
  `package` varchar(128) DEFAULT NULL,
  `android_url` varchar(256) DEFAULT NULL,
  `ios_url` varchar(256) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- 表的结构 `shua_article`
--

DROP TABLE IF EXISTS `shua_article`;
CREATE TABLE `shua_article` (
  `id` int UNSIGNED NOT NULL,
  `zid` int UNSIGNED NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `addtime` datetime NOT NULL,
  `count` int UNSIGNED NOT NULL DEFAULT '0',
  `top` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_batch`
--

DROP TABLE IF EXISTS `shua_batch`;
CREATE TABLE `shua_batch` (
  `batch` varchar(20) NOT NULL,
  `allmoney` decimal(10,2) NOT NULL,
  `count` int NOT NULL DEFAULT '0',
  `time` datetime DEFAULT NULL,
  `status` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- 表的结构 `shua_batch2`
--

DROP TABLE IF EXISTS `shua_batch2`;
CREATE TABLE `shua_batch2` (
  `batch` varchar(20) NOT NULL,
  `allmoney` decimal(10,2) NOT NULL,
  `count` int NOT NULL DEFAULT '0',
  `time` datetime DEFAULT NULL,
  `status` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- 表的结构 `shua_cache`
--

DROP TABLE IF EXISTS `shua_cache`;
CREATE TABLE `shua_cache` (
  `k` varchar(32) NOT NULL,
  `v` longtext,
  `expire` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `shua_cache`
--



-- --------------------------------------------------------

--
-- 表的结构 `shua_cart`
--

DROP TABLE IF EXISTS `shua_cart`;
CREATE TABLE `shua_cart` (
  `id` int UNSIGNED NOT NULL,
  `userid` varchar(32) NOT NULL,
  `zid` int UNSIGNED NOT NULL DEFAULT '1',
  `tid` int NOT NULL,
  `input` text NOT NULL,
  `num` int UNSIGNED NOT NULL DEFAULT '1',
  `money` varchar(32) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `blockdj` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_class`
--

DROP TABLE IF EXISTS `shua_class`;
CREATE TABLE `shua_class` (
  `cid` int UNSIGNED NOT NULL,
  `zid` int UNSIGNED NOT NULL DEFAULT '1',
  `sort` int NOT NULL DEFAULT '10',
  `name` varchar(255) NOT NULL,
  `shopimg` text,
  `block` text,
  `blockpay` varchar(80) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_config`
--

DROP TABLE IF EXISTS `shua_config`;
CREATE TABLE `shua_config` (
  `k` varchar(32) NOT NULL,
  `v` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `shua_config`
--

INSERT INTO `shua_config` (`k`, `v`) VALUES
('admin_pwd', '123456'),
('admin_user', 'admin'),
('adminlogin', '2023-08-10 02:10:29'),
('alipay_api', '2'),
('alipay_appid', ''),
('alipay_privatekey', ''),
('alipay_publickey', ''),
('anounce', '<p>\r\n<li class=\"list-group-item\"><span class=\"btn btn-danger btn-xs\">1</span> 售后问题可直接联系平台在线QQ客服</li>\r\n<li class=\"list-group-item\"><span class=\"btn btn-success btn-xs\">2</span> 下单之前请一定要看完该商品的注意事项再进行下单！</li>\r\n<li class=\"list-group-item\"><span class=\"btn btn-info btn-xs\">3</span> 所有业务全部恢复，都可以正常下单，欢迎尝试</li>\r\n<li class=\"list-group-item\"><span class=\"btn btn-warning btn-xs\">4</span> 温馨提示：请勿重复下单哦！必须要等待前面任务订单完成才可以下单！</li>\r\n<li class=\"list-group-item\"><span class=\"btn btn-primary btn-xs\">5</span> <a href=\"./user/regsite.php\">价格贵？不怕，点击0元搭建，在后台超低价下单！</a></li>\r\n<div class=\"btn-group btn-group-justified\">\r\n<a target=\"_blank\" class=\"btn btn-info\" href=\"http://wpa.qq.com/msgrd?v=3&uin=123456&site=qq&menu=yes\"><i class=\"fa fa-qq\"></i> 联系客服</a>\r\n<a target=\"_blank\" class=\"btn btn-warning\" href=\"http://qun.qq.com/join.html\"><i class=\"fa fa-users\"></i> 官方Q群</a>\r\n<a target=\"_blank\" class=\"btn btn-danger\" href=\"./\"><i class=\"fa fa-cloud-download\"></i> APP下载</a>\r\n</div></p>'),
('apikey', ''),
('articlenum', ''),
('blacklist', ''),
('bottom', ''),
('cache', ''),
('captcha_open_free', '1'),
('captcha_open_reg', '1'),
('cdnpublic', '0'),
('chatframe', ''),
('cishu', '3'),
('classblock', '0'),
('daiguaurl', ''),
('datepoint', ''),
('description', '绫华自助下单系统，专注数字娱乐产品、网络生活服务产品销售，只为您方便、快捷、省心！'),
('epay_key', ''),
('epay_key3', ''),
('epay_pid', ''),
('epay_pid3', ''),
('epay_url', ''),
('epay_url3', ''),
('faka_input', '0'),
('faka_inputname', ''),
('faka_mail', '<b>商品名称：</b> [name]<br/><b>购买时间：</b>[date]<br/><b>以下是你的卡密信息：</b><br/>[kmdata]<br/>----------<br/><b>使用说明：</b><br/>[alert]<br/>----------<br/>云商城自助下单平台<br/>[domain]'),
('faka_showleft', '1'),
('fanghong_api', '0'),
('fanghong_gfpattern', ''),
('fanghong_gftoken', ''),
('fanghong_gftype', ''),
('fanghong_key', ''),
('fanghong_url', ''),
('fenzhan_adds', '0'),
('fenzhan_buy', '1'),
('fenzhan_cost', ''),
('fenzhan_cost2', ''),
('fenzhan_daifu', '0'),
('fenzhan_domain', ''),
('fenzhan_editd', ''),
('fenzhan_edithtml', '1'),
('fenzhan_expiry', '12'),
('fenzhan_free', '0'),
('fenzhan_gift', '200:5'),
('fenzhan_jiakuanka', '0'),
('fenzhan_kfqq', '1'),
('fenzhan_page', '0'),
('fenzhan_price', '0.03'),
('fenzhan_price2', '0.03'),
('fenzhan_pricelimit', '1'),
('fenzhan_rank', '1'),
('fenzhan_regalert', '0'),
('fenzhan_regrand', '0'),
('fenzhan_remain', ''),
('fenzhan_skimg', '1'),
('fenzhan_template', '0'),
('fenzhan_tixian', '1'),
('fenzhan_tixian_alipay', '1'),
('fenzhan_tixian_qq', '1'),
('fenzhan_tixian_wx', '1'),
('fenzhan_upgrade', ''),
('forcelogin', '0'),
('forceloginhome', '0'),
('forcermb', '0'),
('gg_search', '<span class=\"label label-primary\">待处理</span> 说明正在努力提交到服务器！<p></p><p></p><span class=\"label label-success\">已完成</span> 已经提交到接口正在处理！<p></p><p></p><span class=\"label label-warning\">处理中</span> 已经开始为您开单 请耐心等！<p></p><p></p><span class=\"label label-danger\">有异常</span> 下单信息有误 联系客服处理！'),
('gift_open', '0'),
('hide_tongji', '0'),
('invite_content', '特价名片赞0.1元起，免费领名片赞，空间人气、QQ钻、大会员、名片赞、说说赞、空间访问、全民K歌，链接：[url] (请复制链接到浏览器打开)'),
('keywords', 'QQ云商城,自助下单,网红助手,网红速成'),
('kfqq', '123456'),
('kfwx', ''),
('lt_version', '1016'),
('mail_port', '465'),
('mail_smtp', 'smtp.qq.com'),
('modal', ''),
('openbatchorder', '0'),
('ordername', ''),
('parapet', '0'),
('payapi', ''),
('payapi2', ''),
('payapi3', ''),
('paymsg', '<hr/>小提示：<b style=\"color:red\">如果微信出现无法付款时，您可以把微信的钱转到QQ里，然后使用QQ钱包支付！<a href=\"./?mod=wx\" target=\"_blank\">点击查看教程</a></b>'),
('pricejk_time', '600'),
('qiandao_day', '15'),
('qiandao_mult', '1.05'),
('qiandao_reward', '0.02'),
('qqjump', '0'),
('qqpay_api', '2'),
('queryorderlimit', '0'),
('recharge_min', ''),
('search_open', '1'),
('selfrefund', '0'),
('shopdesc_editor', '1'),
('shoppingcart', '1'),
('show_changepwd', '0'),
('show_complain', '0'),
('sitename', '绫华自助下单系统'),
('sitename_hide', '0'),
('style', '1'),
('sup_bond', '0'),
('sup_daifu', '1'),
('sup_skimg', '1'),
('sup_tixian', '1'),
('sup_tixian_alipay', '1'),
('sup_tixian_min', ''),
('sup_tixian_qq', '1'),
('sup_tixian_rate', '98'),
('sup_tixian_wx', '1'),
('template', 'simple'),
('template_m', '0'),
('title', ''),
('tixian_days', ''),
('tixian_limit', '1'),
('tixian_min', '10'),
('tixian_rate', '98'),
('tongji_cachetime', '1691620350'),
('tongji_time', '300'),
('ui_background', '3'),
('ui_bing', '0'),
('ui_color1', ''),
('ui_color2', ''),
('ui_colorto', '0'),
('ui_shop', '0'),
('ui_user', '0'),
('updatestatus', '0'),
('updatestatus_interval', '6'),
('user_level', '0'),
('user_open', '1'),
('verify_open', '1'),
('version', '1010'),
('workorder_open', '1'),
('workorder_type', '业务补单|卡密错误|充值没到账|订单中途改了密码'),
('wxpay_api', '2');

-- --------------------------------------------------------

--
-- 表的结构 `shua_faka`
--

DROP TABLE IF EXISTS `shua_faka`;
CREATE TABLE `shua_faka` (
  `kid` int UNSIGNED NOT NULL,
  `tid` int UNSIGNED NOT NULL,
  `km` varchar(255) DEFAULT NULL,
  `pw` varchar(255) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `usetime` datetime DEFAULT NULL,
  `orderid` int UNSIGNED NOT NULL DEFAULT '0',
  `sid` int UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_gift`
--

DROP TABLE IF EXISTS `shua_gift`;
CREATE TABLE `shua_gift` (
  `id` int UNSIGNED NOT NULL,
  `name` text NOT NULL,
  `tid` int UNSIGNED NOT NULL,
  `rate` int NOT NULL,
  `ok` tinyint(1) NOT NULL DEFAULT '0',
  `not` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_giftlog`
--

DROP TABLE IF EXISTS `shua_giftlog`;
CREATE TABLE `shua_giftlog` (
  `id` int UNSIGNED NOT NULL,
  `zid` int UNSIGNED NOT NULL DEFAULT '0',
  `tid` int UNSIGNED NOT NULL,
  `gid` int UNSIGNED NOT NULL,
  `userid` varchar(32) NOT NULL,
  `ip` varchar(20) NOT NULL,
  `addtime` datetime DEFAULT NULL,
  `tradeno` varchar(32) DEFAULT NULL,
  `input` varchar(64) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_invite`
--

DROP TABLE IF EXISTS `shua_invite`;
CREATE TABLE `shua_invite` (
  `id` int UNSIGNED NOT NULL,
  `nid` int UNSIGNED NOT NULL,
  `tid` int UNSIGNED NOT NULL,
  `qq` varchar(20) NOT NULL,
  `input` text NOT NULL,
  `key` varchar(30) NOT NULL,
  `ip` varchar(25) DEFAULT NULL,
  `plan` int UNSIGNED NOT NULL DEFAULT '0',
  `click` int UNSIGNED NOT NULL DEFAULT '0',
  `count` int UNSIGNED NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_invitelog`
--

DROP TABLE IF EXISTS `shua_invitelog`;
CREATE TABLE `shua_invitelog` (
  `id` int UNSIGNED NOT NULL,
  `iid` int UNSIGNED NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `orderid` int UNSIGNED DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_inviteshop`
--

DROP TABLE IF EXISTS `shua_inviteshop`;
CREATE TABLE `shua_inviteshop` (
  `id` int UNSIGNED NOT NULL,
  `tid` int UNSIGNED NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `times` tinyint(1) NOT NULL DEFAULT '0',
  `value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `sort` int NOT NULL DEFAULT '10',
  `addtime` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_kms`
--

DROP TABLE IF EXISTS `shua_kms`;
CREATE TABLE `shua_kms` (
  `kid` int UNSIGNED NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `zid` int UNSIGNED NOT NULL DEFAULT '0',
  `tid` int UNSIGNED NOT NULL DEFAULT '0',
  `num` int UNSIGNED NOT NULL DEFAULT '1',
  `km` varchar(255) NOT NULL,
  `money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `addtime` timestamp NULL DEFAULT NULL,
  `usetime` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `orderid` int UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_logs`
--

DROP TABLE IF EXISTS `shua_logs`;
CREATE TABLE `shua_logs` (
  `id` int UNSIGNED NOT NULL,
  `action` varchar(32) NOT NULL,
  `param` varchar(255) NOT NULL,
  `result` text,
  `addtime` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_message`
--

DROP TABLE IF EXISTS `shua_message`;
CREATE TABLE `shua_message` (
  `id` int UNSIGNED NOT NULL,
  `zid` int UNSIGNED NOT NULL DEFAULT '1',
  `type` int NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `color` varchar(20) DEFAULT NULL,
  `addtime` datetime NOT NULL,
  `count` int UNSIGNED NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_orders`
--

DROP TABLE IF EXISTS `shua_orders`;
CREATE TABLE `shua_orders` (
  `id` int UNSIGNED NOT NULL,
  `tid` int UNSIGNED NOT NULL,
  `zid` int UNSIGNED NOT NULL DEFAULT '1',
  `input` varchar(256) NOT NULL,
  `input2` varchar(256) DEFAULT NULL,
  `input3` varchar(256) DEFAULT NULL,
  `input4` varchar(256) DEFAULT NULL,
  `input5` varchar(256) DEFAULT NULL,
  `value` int UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `djzt` tinyint(1) NOT NULL DEFAULT '0',
  `djorder` varchar(32) DEFAULT NULL,
  `url` varchar(32) DEFAULT NULL,
  `result` text,
  `userid` varchar(32) DEFAULT NULL,
  `tradeno` varchar(32) DEFAULT NULL,
  `money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cost` decimal(10,2) NOT NULL DEFAULT '0.00',
  `addtime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `uptime` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_pay`
--

DROP TABLE IF EXISTS `shua_pay`;
CREATE TABLE `shua_pay` (
  `trade_no` varchar(64) NOT NULL,
  `api_trade_no` varchar(64) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `channel` varchar(10) DEFAULT NULL,
  `zid` int UNSIGNED NOT NULL DEFAULT '1',
  `tid` int NOT NULL,
  `input` text NOT NULL,
  `num` int UNSIGNED NOT NULL DEFAULT '1',
  `addtime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `money` varchar(32) DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `userid` varchar(32) DEFAULT NULL,
  `inviteid` int UNSIGNED DEFAULT NULL,
  `domain` varchar(64) DEFAULT NULL,
  `blockdj` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_points`
--

DROP TABLE IF EXISTS `shua_points`;
CREATE TABLE `shua_points` (
  `id` int UNSIGNED NOT NULL,
  `zid` int UNSIGNED NOT NULL DEFAULT '0',
  `action` varchar(255) NOT NULL,
  `point` decimal(10,2) NOT NULL DEFAULT '0.00',
  `bz` varchar(1024) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `orderid` int UNSIGNED DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_price`
--

DROP TABLE IF EXISTS `shua_price`;
CREATE TABLE `shua_price` (
  `id` int UNSIGNED NOT NULL,
  `zid` int UNSIGNED NOT NULL DEFAULT '0',
  `kind` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 倍数 1 价格',
  `name` varchar(255) NOT NULL,
  `p_0` decimal(8,2) NOT NULL DEFAULT '0.00',
  `p_1` decimal(8,2) NOT NULL DEFAULT '0.00',
  `p_2` decimal(8,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_qiandao`
--

DROP TABLE IF EXISTS `shua_qiandao`;
CREATE TABLE `shua_qiandao` (
  `id` int UNSIGNED NOT NULL,
  `zid` int UNSIGNED NOT NULL DEFAULT '1',
  `qq` varchar(20) DEFAULT NULL,
  `reward` decimal(10,2) NOT NULL DEFAULT '0.00',
  `date` date NOT NULL,
  `time` datetime NOT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `continue` int UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_sendcode`
--

DROP TABLE IF EXISTS `shua_sendcode`;
CREATE TABLE `shua_sendcode` (
  `id` int NOT NULL,
  `uid` int NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0邮箱 1手机',
  `mode` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0注册 1找回 2改绑',
  `code` varchar(32) NOT NULL,
  `to` varchar(32) DEFAULT NULL,
  `time` int NOT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `status` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- 表的结构 `shua_settle`
--

DROP TABLE IF EXISTS `shua_settle`;
CREATE TABLE `shua_settle` (
  `id` int NOT NULL,
  `uid` int NOT NULL,
  `batch` varchar(20) DEFAULT NULL,
  `auto` int NOT NULL DEFAULT '1',
  `type` int NOT NULL DEFAULT '1',
  `account` varchar(128) NOT NULL,
  `username` varchar(128) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `realmoney` decimal(10,2) NOT NULL,
  `addtime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `status` int NOT NULL DEFAULT '0',
  `transfer_status` int NOT NULL DEFAULT '0',
  `transfer_result` varchar(64) DEFAULT NULL,
  `transfer_date` datetime DEFAULT NULL,
  `result` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- 表的结构 `shua_shequ`
--

DROP TABLE IF EXISTS `shua_shequ`;
CREATE TABLE `shua_shequ` (
  `id` int UNSIGNED NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `paypwd` varchar(255) DEFAULT NULL,
  `paytype` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(20) NOT NULL,
  `result` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `remark` varchar(255) DEFAULT NULL,
  `protocol` tinyint(1) NOT NULL DEFAULT '0',
  `monitor` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_site`
--

DROP TABLE IF EXISTS `shua_site`;
CREATE TABLE `shua_site` (
  `zid` int UNSIGNED NOT NULL,
  `upzid` int UNSIGNED NOT NULL DEFAULT '0',
  `utype` int UNSIGNED NOT NULL DEFAULT '0',
  `power` tinyint UNSIGNED NOT NULL DEFAULT '0',
  `domain` varchar(50) DEFAULT NULL,
  `domain2` varchar(50) DEFAULT NULL,
  `user` varchar(20) NOT NULL,
  `pwd` varchar(32) NOT NULL,
  `email` varchar(64) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `qq_openid` varchar(64) DEFAULT NULL,
  `wx_openid` varchar(64) DEFAULT NULL,
  `nickname` varchar(64) DEFAULT NULL,
  `faceimg` varchar(150) DEFAULT NULL,
  `rmb` decimal(10,2) NOT NULL DEFAULT '0.00',
  `rmbtc` decimal(10,2) NOT NULL DEFAULT '0.00',
  `point` int NOT NULL DEFAULT '0',
  `pay_type` int NOT NULL DEFAULT '0',
  `pay_account` varchar(50) DEFAULT NULL,
  `pay_name` varchar(50) DEFAULT NULL,
  `qq` varchar(12) DEFAULT NULL,
  `sitename` varchar(80) DEFAULT NULL,
  `title` varchar(80) DEFAULT NULL,
  `keywords` text,
  `description` text,
  `kfqq` varchar(12) DEFAULT NULL,
  `kfwx` varchar(20) DEFAULT NULL,
  `anounce` text,
  `bottom` text,
  `modal` text,
  `alert` text,
  `price` longtext,
  `iprice` longtext,
  `appurl` varchar(150) DEFAULT NULL,
  `class` varchar(255) DEFAULT NULL,
  `ktfz_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ktfz_price2` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ktfz_domain` text,
  `addtime` datetime DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `template` varchar(10) DEFAULT NULL,
  `msgread` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- 表的结构 `shua_supplier`
--

DROP TABLE IF EXISTS `shua_supplier`;
CREATE TABLE `shua_supplier` (
  `sid` int UNSIGNED NOT NULL,
  `user` varchar(20) NOT NULL,
  `pwd` varchar(32) NOT NULL,
  `email` varchar(64) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `qq_openid` varchar(64) DEFAULT NULL,
  `wx_openid` varchar(64) DEFAULT NULL,
  `nickname` varchar(64) DEFAULT NULL,
  `faceimg` varchar(150) DEFAULT NULL,
  `rmb` decimal(10,2) NOT NULL DEFAULT '0.00',
  `rmbtc` decimal(10,2) NOT NULL DEFAULT '0.00',
  `bond` decimal(10,2) NOT NULL DEFAULT '0.00',
  `point` int NOT NULL DEFAULT '0',
  `pay_type` int NOT NULL DEFAULT '0',
  `pay_account` varchar(50) DEFAULT NULL,
  `pay_name` varchar(50) DEFAULT NULL,
  `qq` varchar(12) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `msgread` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- 表的结构 `shua_suppoints`
--

DROP TABLE IF EXISTS `shua_suppoints`;
CREATE TABLE `shua_suppoints` (
  `id` int UNSIGNED NOT NULL,
  `sid` int UNSIGNED NOT NULL DEFAULT '0',
  `action` varchar(255) NOT NULL,
  `point` decimal(10,2) NOT NULL DEFAULT '0.00',
  `bz` varchar(1024) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `orderid` int UNSIGNED DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_suptixian`
--

DROP TABLE IF EXISTS `shua_suptixian`;
CREATE TABLE `shua_suptixian` (
  `id` int UNSIGNED NOT NULL,
  `sid` int UNSIGNED NOT NULL,
  `money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `realmoney` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pay_type` int NOT NULL DEFAULT '0',
  `pay_account` varchar(50) NOT NULL,
  `pay_name` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `addtime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `note` text,
  `batch` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_tixian`
--

DROP TABLE IF EXISTS `shua_tixian`;
CREATE TABLE `shua_tixian` (
  `id` int UNSIGNED NOT NULL,
  `zid` int UNSIGNED NOT NULL,
  `money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `realmoney` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pay_type` int NOT NULL DEFAULT '0',
  `pay_account` varchar(50) NOT NULL,
  `pay_name` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `addtime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `note` text,
  `batch` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_toollogs`
--

DROP TABLE IF EXISTS `shua_toollogs`;
CREATE TABLE `shua_toollogs` (
  `id` int UNSIGNED NOT NULL,
  `content` longtext NOT NULL,
  `date` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_tools`
--

DROP TABLE IF EXISTS `shua_tools`;
CREATE TABLE `shua_tools` (
  `tid` int UNSIGNED NOT NULL,
  `zid` int UNSIGNED NOT NULL DEFAULT '1',
  `cid` int UNSIGNED NOT NULL DEFAULT '0',
  `sort` int NOT NULL DEFAULT '10',
  `name` varchar(255) NOT NULL,
  `value` int UNSIGNED NOT NULL DEFAULT '0',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `prid` int NOT NULL DEFAULT '0',
  `cost` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cost2` decimal(10,2) NOT NULL DEFAULT '0.00',
  `prices` varchar(100) DEFAULT NULL,
  `input` varchar(250) NOT NULL,
  `inputs` varchar(255) DEFAULT NULL,
  `desc` text,
  `alert` text,
  `shopimg` text,
  `validate` tinyint(1) NOT NULL DEFAULT '0',
  `valiserv` varchar(15) DEFAULT NULL,
  `min` int NOT NULL DEFAULT '0',
  `max` int NOT NULL DEFAULT '0',
  `is_curl` tinyint(1) NOT NULL DEFAULT '0',
  `curl` varchar(255) DEFAULT NULL,
  `repeat` tinyint(1) NOT NULL DEFAULT '0',
  `multi` tinyint(1) NOT NULL DEFAULT '0',
  `shequ` int NOT NULL DEFAULT '0',
  `goods_id` int NOT NULL DEFAULT '0',
  `goods_type` int NOT NULL DEFAULT '0',
  `goods_param` text,
  `close` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `uptime` int NOT NULL DEFAULT '0',
  `sales` int NOT NULL DEFAULT '0',
  `stock` int DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `goods_sid` int DEFAULT NULL,
  `audit_status` tinyint(1) NOT NULL DEFAULT '0',
  `sup_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ts` tinyint(1) DEFAULT '0',
  `rebate_open` tinyint(1) DEFAULT '0',
  `rebate` decimal(10,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `shua_workorder`
--

DROP TABLE IF EXISTS `shua_workorder`;
CREATE TABLE `shua_workorder` (
  `id` int UNSIGNED NOT NULL,
  `zid` int UNSIGNED NOT NULL DEFAULT '1',
  `type` int UNSIGNED NOT NULL DEFAULT '0',
  `orderid` int UNSIGNED NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `picurl` varchar(150) DEFAULT NULL,
  `addtime` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `ts` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转储表的索引
--

--
-- 表的索引 `shua_account`
--
ALTER TABLE `shua_account`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `shua_apps`
--
ALTER TABLE `shua_apps`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `domain` (`domain`);

--
-- 表的索引 `shua_article`
--
ALTER TABLE `shua_article`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `shua_cache`
--
ALTER TABLE `shua_cache`
  ADD PRIMARY KEY (`k`);

--
-- 表的索引 `shua_cart`
--
ALTER TABLE `shua_cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`);

--
-- 表的索引 `shua_class`
--
ALTER TABLE `shua_class`
  ADD PRIMARY KEY (`cid`);

--
-- 表的索引 `shua_config`
--
ALTER TABLE `shua_config`
  ADD PRIMARY KEY (`k`);

--
-- 表的索引 `shua_faka`
--
ALTER TABLE `shua_faka`
  ADD PRIMARY KEY (`kid`),
  ADD KEY `orderid` (`orderid`),
  ADD KEY `tid` (`tid`),
  ADD KEY `getleft` (`tid`,`orderid`);

--
-- 表的索引 `shua_gift`
--
ALTER TABLE `shua_gift`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `shua_giftlog`
--
ALTER TABLE `shua_giftlog`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `shua_invite`
--
ALTER TABLE `shua_invite`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`),
  ADD KEY `nid` (`nid`),
  ADD KEY `qq` (`qq`);

--
-- 表的索引 `shua_invitelog`
--
ALTER TABLE `shua_invitelog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `iid` (`iid`,`status`),
  ADD KEY `iidip` (`iid`,`ip`);

--
-- 表的索引 `shua_inviteshop`
--
ALTER TABLE `shua_inviteshop`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tid` (`tid`);

--
-- 表的索引 `shua_kms`
--
ALTER TABLE `shua_kms`
  ADD PRIMARY KEY (`kid`);

--
-- 表的索引 `shua_logs`
--
ALTER TABLE `shua_logs`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `shua_message`
--
ALTER TABLE `shua_message`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type` (`type`);

--
-- 表的索引 `shua_orders`
--
ALTER TABLE `shua_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `zid` (`zid`),
  ADD KEY `input` (`input`(191)),
  ADD KEY `userid` (`userid`);

--
-- 表的索引 `shua_pay`
--
ALTER TABLE `shua_pay`
  ADD PRIMARY KEY (`trade_no`);

--
-- 表的索引 `shua_points`
--
ALTER TABLE `shua_points`
  ADD PRIMARY KEY (`id`),
  ADD KEY `zid` (`zid`),
  ADD KEY `action` (`action`(191)),
  ADD KEY `orderid` (`orderid`);

--
-- 表的索引 `shua_price`
--
ALTER TABLE `shua_price`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `shua_qiandao`
--
ALTER TABLE `shua_qiandao`
  ADD PRIMARY KEY (`id`),
  ADD KEY `zid` (`zid`),
  ADD KEY `ip` (`ip`),
  ADD KEY `date` (`date`);

--
-- 表的索引 `shua_sendcode`
--
ALTER TABLE `shua_sendcode`
  ADD PRIMARY KEY (`id`),
  ADD KEY `code` (`code`);

--
-- 表的索引 `shua_shequ`
--
ALTER TABLE `shua_shequ`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `shua_site`
--
ALTER TABLE `shua_site`
  ADD PRIMARY KEY (`zid`),
  ADD UNIQUE KEY `user` (`user`),
  ADD KEY `domain` (`domain`),
  ADD KEY `domain2` (`domain2`),
  ADD KEY `qq` (`qq`),
  ADD KEY `qq_openid` (`qq_openid`),
  ADD KEY `wx_openid` (`wx_openid`);

--
-- 表的索引 `shua_supplier`
--
ALTER TABLE `shua_supplier`
  ADD PRIMARY KEY (`sid`),
  ADD UNIQUE KEY `user` (`user`),
  ADD KEY `qq` (`qq`),
  ADD KEY `qq_openid` (`qq_openid`),
  ADD KEY `wx_openid` (`wx_openid`);

--
-- 表的索引 `shua_suppoints`
--
ALTER TABLE `shua_suppoints`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sid` (`sid`),
  ADD KEY `action` (`action`(191)),
  ADD KEY `orderid` (`orderid`);

--
-- 表的索引 `shua_suptixian`
--
ALTER TABLE `shua_suptixian`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sid` (`sid`);

--
-- 表的索引 `shua_tixian`
--
ALTER TABLE `shua_tixian`
  ADD PRIMARY KEY (`id`),
  ADD KEY `zid` (`zid`);

--
-- 表的索引 `shua_toollogs`
--
ALTER TABLE `shua_toollogs`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `shua_tools`
--
ALTER TABLE `shua_tools`
  ADD PRIMARY KEY (`tid`),
  ADD KEY `cid` (`cid`);

--
-- 表的索引 `shua_workorder`
--
ALTER TABLE `shua_workorder`
  ADD PRIMARY KEY (`id`),
  ADD KEY `zid` (`zid`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `shua_account`
--
ALTER TABLE `shua_account`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_apps`
--
ALTER TABLE `shua_apps`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_article`
--
ALTER TABLE `shua_article`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_cart`
--
ALTER TABLE `shua_cart`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_class`
--
ALTER TABLE `shua_class`
  MODIFY `cid` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_faka`
--
ALTER TABLE `shua_faka`
  MODIFY `kid` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_gift`
--
ALTER TABLE `shua_gift`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_giftlog`
--
ALTER TABLE `shua_giftlog`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_invite`
--
ALTER TABLE `shua_invite`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_invitelog`
--
ALTER TABLE `shua_invitelog`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_inviteshop`
--
ALTER TABLE `shua_inviteshop`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_kms`
--
ALTER TABLE `shua_kms`
  MODIFY `kid` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_logs`
--
ALTER TABLE `shua_logs`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_message`
--
ALTER TABLE `shua_message`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_orders`
--
ALTER TABLE `shua_orders`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_points`
--
ALTER TABLE `shua_points`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_price`
--
ALTER TABLE `shua_price`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_qiandao`
--
ALTER TABLE `shua_qiandao`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_sendcode`
--
ALTER TABLE `shua_sendcode`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_shequ`
--
ALTER TABLE `shua_shequ`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_site`
--
ALTER TABLE `shua_site`
  MODIFY `zid` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_supplier`
--
ALTER TABLE `shua_supplier`
  MODIFY `sid` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_suppoints`
--
ALTER TABLE `shua_suppoints`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_suptixian`
--
ALTER TABLE `shua_suptixian`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- 使用表AUTO_INCREMENT `shua_tixian`
--
ALTER TABLE `shua_tixian`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- 使用表AUTO_INCREMENT `shua_toollogs`
--
ALTER TABLE `shua_toollogs`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `shua_tools`
--
ALTER TABLE `shua_tools`
  MODIFY `tid` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用表AUTO_INCREMENT `shua_workorder`
--
ALTER TABLE `shua_workorder`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
