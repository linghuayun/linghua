ALTER TABLE `pre_tools` ADD `placeholder` VARCHAR(255) NOT NULL DEFAULT '';
ALTER TABLE `pre_supplier` ADD `is_hide` TINYINT(1) NOT NULL DEFAULT '1';