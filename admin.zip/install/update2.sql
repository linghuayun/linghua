ALTER TABLE `pre_tools`
ADD COLUMN `ts` tinyint(1) DEFAULT '0';

ALTER TABLE `pre_workorder`
ADD COLUMN `ts` tinyint(1) DEFAULT 0;