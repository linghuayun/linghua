<?php
$install = true;
require_once('../includes/common.php');
@header('Content-Type: text/html; charset=UTF-8');
$newVersion = 1010;
$sqls = '';
$versionList = [
    [
        'version' => 1011,
        'sql' => 'update.sql'
    ],
    [
        'version' => 1012,
        'sql' => 'update2.sql'
    ],
    [
        'version' => 1013,
        'sql' => 'update3.sql'
    ],
    [
        'version' => 1014,
        'sql' => 'update4.sql'
    ],
    [
        'version' => 1015,
        'sql' => 'update5.sql'
    ],
    [
        'version' => 1016,
        'sql' => 'update6.sql'
    ],
    [
        'version' => 1017,
        'sql' => 'update7.sql'
    ],
    [
        'version' => 1018,
        'sql' => 'update8.sql'
    ]
];
foreach ($versionList as $res){
    if($conf['sf_version'] < $res['version']){
        $sqls .= file_get_contents($res['sql']);
        if($newVersion < $res['version']) $newVersion = $res['version'];
    }
}
if(empty($sqls))exit("<script language='javascript'>alert('你的网站已经升级到最新版本了！');window.location.href='../';</script>");

$explode = explode(';', $sqls);
foreach ($explode as $sql) {
    if ($sql = trim($sql)) {
        $DB->exec($sql);
    }
}
saveSetting('sf_version',$newVersion);
$CACHE->clear();
exit("<script language='javascript'>alert('网站数据库升级完成！');window.location.href='../';</script>");
?>