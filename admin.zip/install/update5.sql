DROP TABLE IF EXISTS `pre_toollogs`;
CREATE TABLE `pre_toollogs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `content` longtext NOT NULL,
  `date` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `pre_tools` ADD COLUMN `rebate_open` tinyint(1) DEFAULT 0;
ALTER TABLE `pre_tools` ADD COLUMN `rebate` decimal(10,2) NOT NULL DEFAULT '0.00';